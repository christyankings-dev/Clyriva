"""Regenera a edição HTML portátil e a moldura da demonstração por arquivo."""
from pathlib import Path
import json
ROOT = Path(__file__).resolve().parent
read = lambda name: (ROOT/name).read_text(encoding='utf-8')
admin = read('admin.html')
# A mesma implementação atende os dois modos. Nenhuma credencial entra nesses arquivos.
shell=admin
for name in ('panel.css','rotina.css'):
    shell=shell.replace('<link rel="stylesheet" href="'+name+'">','<style>'+read(name)+'</style>')
for name in ('core.js','rotina.js','panel.js'):
    shell=shell.replace('<script src="'+name+'"></script>','<script>'+read(name)+'</script>')
local=shell.replace('data-mode="online">','data-mode="local">',1).replace('Sincronização pelo portal','Gravação neste navegador').replace('<title>', '<title>Local · ',1)
(ROOT/'Clyriva_v1_4_Local_Busca_CNPJ.html').write_text(local,encoding='utf-8')
# Por HTTP a moldura usa admin.html. file:// atribui origens opacas a arquivos distintos.
(ROOT/'file-demo.js').write_text("if(location.protocol==='file:')window.ClyrivaFileShell="+json.dumps(shell,ensure_ascii=False)+";\n",encoding='utf-8')
