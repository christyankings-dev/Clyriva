@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 servidor.py --abrir-local
) else (
  python servidor.py --abrir-local
)
pause
