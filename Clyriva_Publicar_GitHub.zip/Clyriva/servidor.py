"""Servidor do Clyriva. Uso local: python servidor.py. Bibliotecas padrão do Python 3.9+."""
import argparse
from collections import OrderedDict, deque
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
LOCAL_HTML = 'Clyriva_v1_4_Local_Busca_CNPJ.html'  # caminho preservado para instalações v1.4
ASSETS = {
    'index.html': 'text/html', 'admin.html': 'text/html', LOCAL_HTML: 'text/html',
    'core.js': 'text/javascript', 'app.js': 'text/javascript', 'file-demo.js': 'text/javascript',
    'panel.js': 'text/javascript', 'config.js': 'text/javascript', 'vendor/supabase.js': 'text/javascript',
    'panel.css': 'text/css', 'rotina.css': 'text/css', 'rotina.js': 'text/javascript',
}
PROVIDERS = {
    'brasilapi': 'https://brasilapi.com.br/api/cnpj/v1/',
    'cnpjws': 'https://publica.cnpj.ws/cnpj/',
}
TTL = 15 * 60
cache = OrderedDict()
hits = OrderedDict()
blocked_until = {}
lock = threading.Lock()

def valid_cnpj(value):
    if not re.fullmatch(r'[A-Z0-9]{12}[0-9]{2}', value) or len(set(value)) == 1:
        return False
    digits = [ord(ch) - 48 for ch in value]
    for size in (12, 13):
        total = sum(x * (2 + (size - 1 - i) % 8) for i, x in enumerate(digits[:size]))
        rem = total % 11
        if digits[size] != (0 if rem < 2 else 11 - rem):
            return False
    return True

def project(record, source, cnpj):
    """O navegador recebe somente os campos usados pelo cadastro."""
    def pick(item, keys):
        if not isinstance(item, dict):
            return {}
        return {k: item[k] for k in keys.split() if k in item and not isinstance(item[k], (dict, list))}
    if not isinstance(record, dict):
        raise ValueError()
    est = record.get('estabelecimento') if source == 'cnpjws' else record
    if not isinstance(est, dict) or est.get('cnpj') != cnpj or not isinstance(record.get('razao_social'), str) or not record['razao_social'].strip():
        raise ValueError()
    common = 'cnpj nome_fantasia data_inicio_atividade cep tipo_logradouro logradouro numero complemento bairro email'
    if source == 'brasilapi':
        return pick(record, common + ' razao_social cnae_fiscal_descricao cnae_fiscal descricao_situacao_cadastral natureza_juridica porte descricao_porte descricao_tipo_de_logradouro municipio uf ddd_telefone1 opcao_pelo_mei opcao_pelo_simples')
    result = pick(record, 'razao_social')
    for k, keys in [('porte','descricao'), ('natureza_juridica','descricao'), ('simples','mei simples')]:
        result[k] = pick(record.get(k), keys)
    branch = pick(est, common + ' situacao_cadastral ddd1 telefone1')
    for k, keys in [('cidade','nome'), ('estado','sigla'), ('atividade_principal','id descricao')]:
        branch[k] = pick(est.get(k), keys)
    result['estabelecimento'] = branch
    return result

def lookup(provider, cnpj, ip):
    key = (provider, cnpj)
    with lock:
        now = time.monotonic()
        item = cache.get(key)
        if item and now - item[0] < TTL:
            cache.move_to_end(key)
            return 200, item[1], {'X-Clyriva-Consulted-At':item[2]}
        if now < blocked_until.get(provider, 0):
            return 429, {'erro':'Limite temporário na fonte.'}, {'Retry-After':str(max(1,int(blocked_until[provider]-now)))}
        window = hits.setdefault(ip, deque())
        while window and now - window[0] >= 60:
            window.popleft()
        if len(window) >= 30:
            return 429, {'erro':'Aguarde para consultar novamente.'}, {'Retry-After':'60'}
        window.append(now)
        hits.move_to_end(ip)
        if len(hits)>4096:
            hits.popitem(last=False)
    try:
        req = Request(PROVIDERS[provider]+cnpj, headers={'Accept':'application/json','User-Agent':'Clyriva/1.6 (consulta cadastral)'})
        with urlopen(req, timeout=8) as res:
            body = res.read(512*1024+1)
            if len(body)>512*1024:
                raise ValueError()
            result = project(json.loads(body),provider,cnpj)
    except HTTPError as exc:
        status = exc.code if exc.code in (400,403,404,422,429) else 502
        if status == 429:
            retry = exc.headers.get('Retry-After','')
            seconds=min(3600,max(1,int(retry))) if retry.isdecimal() else 60
            with lock:
                blocked_until[provider]=time.monotonic()+seconds
            return 429, {'erro':'Limite do provedor.'}, {'Retry-After':str(seconds)}
        return status, {'erro':'A fonte não concluiu a consulta.'}, {}
    except (TimeoutError,URLError,OSError,ValueError):
        return 502, {'erro':'Fonte indisponível ou resposta incompatível.'}, {}
    checked = datetime.now(timezone.utc).isoformat()
    with lock:
        cache[key] = (time.monotonic(),result,checked)
        cache.move_to_end(key)
        if len(cache)>512:
            cache.popitem(last=False)
    return 200,result,{'X-Clyriva-Consulted-At':checked}

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # Evita registrar documentos, credenciais e parâmetros de links de recuperação.
        pass

    def send(self, status, data, mime, headers=None):
        self.send_response(status)
        self.send_header('Content-Type',mime+'; charset=utf-8')
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('X-Frame-Options','SAMEORIGIN')
        self.send_header('Content-Security-Policy',"frame-ancestors 'self'; object-src 'none'; base-uri 'self'")
        for key,value in (headers or {}).items():
            self.send_header(key,value)
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        status,body,mime,headers = resource(urlsplit(self.path).path,self.client_address[0])
        self.send(status,body,mime,headers)

def resource(path,ip):
    if path.startswith('/api/cnpj/'):
        parts=path.split('/')
        if len(parts)!=5 or parts[3] not in PROVIDERS or not valid_cnpj(parts[4]):
            return 400,b'{"erro":"CNPJ ou fonte invalida."}','application/json',{}
        status,result,headers=lookup(parts[3],parts[4],ip)
        return status,json.dumps(result,ensure_ascii=False).encode(),'application/json',headers
    asset='index.html' if path=='/' else path[1:]
    if os.getenv('CLYRIVA_ENV') == 'production' and asset in ('file-demo.js', LOCAL_HTML):
        return 404,b'Arquivo indisponivel.','text/plain',{}
    if asset not in ASSETS:
        return 404,b'Arquivo indisponivel.','text/plain',{}
    data=(ROOT/asset).read_bytes()
    if ASSETS[asset]=='text/html':
        data=data.replace(b'<!-- clyriva-runtime -->',b'<meta name="clyriva-cnpj-proxy" content="/api/cnpj/">',1)
    return 200,data,ASSETS[asset],{}

def application(environ,start_response):
    """Aplicação WSGI para hospedagem HTTPS com servidor de produção."""
    if environ.get('REQUEST_METHOD')!='GET':
        status,body,mime,headers=405,b'Metodo indisponivel.','text/plain',{'Allow':'GET'}
    else:
        status,body,mime,headers=resource(environ.get('PATH_INFO','/'),environ.get('REMOTE_ADDR',''))
    fields={'Content-Type':mime+'; charset=utf-8','Content-Length':str(len(body)),
            'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',
            'X-Frame-Options':'SAMEORIGIN','Content-Security-Policy':"frame-ancestors 'self'; object-src 'none'; base-uri 'self'",**headers}
    start_response(str(status)+' '+HTTPStatus(status).phrase,list(fields.items()))
    return [body]

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--abrir',action='store_true',help='Abrir o portal no navegador após iniciar')
    parser.add_argument('--abrir-local',action='store_true',help='Abrir diretamente o painel administrativo local')
    args=parser.parse_args()
    with ThreadingHTTPServer((args.host,args.port),Handler) as server:
        print('Portal: http://'+args.host+':'+str(server.server_port)+'/\nPainel local: http://'+args.host+':'+str(server.server_port)+'/'+LOCAL_HTML,flush=True)
        if args.abrir or args.abrir_local:
            import webbrowser
            url='http://'+args.host+':'+str(server.server_port)+'/'
            if args.abrir_local:url += LOCAL_HTML
            webbrowser.open(url)
        try:server.serve_forever()
        except KeyboardInterrupt:pass
