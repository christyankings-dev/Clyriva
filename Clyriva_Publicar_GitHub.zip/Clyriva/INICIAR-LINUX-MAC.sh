#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  exec python3 servidor.py --abrir
elif command -v python >/dev/null 2>&1; then
  exec python servidor.py --abrir
else
  echo "Python 3.9 ou superior é necessário para iniciar o Clyriva." >&2
  exit 1
fi
