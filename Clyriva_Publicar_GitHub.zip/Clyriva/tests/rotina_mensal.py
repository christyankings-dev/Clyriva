"""Testa agenda por vencimento e resumo individual usando Chromium e pypdf.
Com --html-v15, abre também uma carteira e um cofre criados pela edição original 1.5."""
import argparse
from datetime import datetime, timezone
import io
import json
import threading
from pathlib import Path
from pypdf import PdfReader
from playwright.sync_api import sync_playwright, expect
from fluxos import ROOT, servidor, browser_start, nav, action, form, saved, vault_fill, passed

MONTH='2026-12'
KEY='carteira-meu-escritorio-v1'
def fixture():
    def tax(id_,due,month=MONTH,status='open',amount=2.51,client='a'):
        return {'id':id_,'clientId':client,'kind':id_,'value':amount,'competence':month,'status':status,'dueDate':due,'notes':'CAMPO_PRIVADO'}
    def task(id_,due,month=MONTH,status='pending',client='a'):
        return {'id':id_,'clientId':client,'title':id_,'competence':month,'status':status,'dueDate':due,'notes':'CAMPO_PRIVADO'}
    def invoice(id_,client,value,status='issued',month=MONTH):
        return {'id':id_,'clientId':client,'number':id_,'competence':month,'value':value,'date':month+'-01','status':status}
    return {'version':1,
      'clients':[{'id':'a','name':'Empresa Alfa','status':'active','monthlyFee':999.83,'notes':'SEGREDO_INTERNO'},
                 {'id':'b','name':'Empresa Beta','status':'active'}],
      'invoices':[invoice('nf1','a',1234.56),invoice('nf2','a',.21),invoice('prevista','a',125,'pending'),
                  invoice('cancelada','a',234,'canceled'),invoice('nfout','a',500,month='2026-11'),invoice('nf-b','b',777)],
      'cash':[{'id':'baixa','clientId':'a','kind':'receipt','value':234.56,'date':'2027-01-06','invoiceId':'nf1'},
              {'id':'centavos','clientId':'a','kind':'receipt','value':.01,'date':'2026-12-01','invoiceId':'nf2'},
              {'id':'sem-vinculo','clientId':'a','kind':'receipt','value':900,'date':'2026-12-30'}],
      'fees':[],
      'taxes':[tax('Guia anterior','2026-12-30','2026-11'),tax('Guia de hoje','2026-12-31'),tax('Guia de janeiro','2027-01-01'),
               tax('Guia já paga','2026-12-30',status='paid'),tax('Guia exclusiva de Beta','2026-12-31',client='b')],
      'tasks':[task('Limite de sete dias','2027-01-07'),task('Fora dos sete dias','2027-01-08'),
               task('Tarefa sem prazo',''),task('Concluída','2026-12-29',status='done'),
               task('Tarefa de hoje','2026-12-31'),task('Tarefa do próximo mês','2027-01-02','2027-01'),
               task('Só para Beta','2026-12-29',client='b')]}

def contents(pdf):
    return ' '.join(' '.join(page.extract_text().split()) for page in PdfReader(io.BytesIO(pdf)).pages)
def run(browser,base):
    ctx=browser.new_context(timezone_id='America/Sao_Paulo',viewport={'width':1280,'height':820})
    ctx.grant_permissions(['clipboard-read','clipboard-write'],origin=base)
    p=ctx.new_page();errors=[]
    p.on('pageerror',lambda e:errors.append(str(e)))
    p.clock.install(time=datetime(2026,12,31,15,0,tzinfo=timezone.utc))
    p.goto(base+'/'+servidor.LOCAL_HTML)
    p.evaluate('([k,v])=>localStorage.setItem(k,JSON.stringify(v))',[KEY,fixture()]);p.reload()
    p.locator('#client-filter').select_option('a')
    ag=p.locator('#agenda-vencimentos');period=ag.locator('select')
    expect(ag).to_contain_text('Guia anterior');expect(ag).not_to_contain_text('Beta')
    period.select_option('late');expect(ag.locator('li')).to_have_count(1);expect(ag).to_contain_text('Guia anterior')
    p.locator('#month').fill('2027-01');expect(ag).to_contain_text('Guia anterior')
    period.select_option('today');expect(ag.locator('li')).to_have_count(2)
    period.select_option('next');expect(ag.locator('li')).to_have_count(3)
    expect(ag).to_contain_text('Limite de sete dias');expect(ag).not_to_contain_text('Fora dos sete dias')
    expect(ag).not_to_contain_text('Guia já paga')
    period.select_option('all');expect(ag.locator('li')).to_have_count(5)
    ag.get_by_role('button',name='Mostrar mais').click();expect(ag).to_contain_text('Tarefa sem prazo')
    expect(ag).not_to_contain_text('Concluída');expect(ag).to_contain_text('Fora dos sete dias')
    passed('agenda por data de vencimento, filtro por empresa, fim de ano, limite inclusivo e prazos ausentes')
    p.locator('#month').fill(MONTH)
    before=p.evaluate('key=>localStorage.getItem(key)',KEY)
    p.locator('[data-action=resumo-cliente]').click()
    dlg=p.locator('#resumo-mensal');sheet=dlg.locator('article')
    expect(sheet).to_contain_text('Empresa Alfa');expect(sheet).to_contain_text('Notas emitidas (2)')
    for text in ['1.234,77','234,57','1.000,20','5,02','Tarefa sem prazo']:
        expect(sheet).to_contain_text(text)
    for text in ['900,00','999,83','Guia anterior','Empresa Beta','SEGREDO_INTERNO','CAMPO_PRIVADO','Tarefa do próximo mês','Guia já paga']:
        expect(sheet).not_to_contain_text(text)
    dlg.get_by_role('button',name='Copiar texto').click();expect(dlg.locator('[role=status]')).to_have_text('Resumo copiado.')
    copied=p.evaluate('navigator.clipboard.readText()')
    assert '1.000,20' in copied and 'Empresa Alfa' in copied and 'SEGREDO_INTERNO' not in copied
    passed('resumo por competência com centavos, baixa posterior, exclusão de previsões e cópia real para a área de transferência')
    dlg.get_by_role('button',name='Imprimir / salvar PDF').click()
    print_doc=dlg.locator('iframe').element_handle().content_frame().content()
    assert 'Empresa Alfa' in print_doc and 'Empresa Beta' not in print_doc and 'Copiar texto' not in print_doc
    print_tab=ctx.new_page();print_tab.set_content(print_doc)
    extracted=contents(print_tab.pdf(format='A4'))
    assert 'Empresa Alfa' in extracted and '1.000,20' in extracted and 'Empresa Beta' not in extracted
    print_tab.close();p.bring_to_front()
    keyboard_pdf=contents(p.pdf(format='A4'))
    assert '1.000,20' in keyboard_pdf and 'Empresa Beta' not in keyboard_pdf and 'Carteira prioritária' not in keyboard_pdf
    # Este caminho simula apenas a recusa do navegador em permitir cópia automática.
    p.evaluate("Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:()=>Promise.reject(Error('bloqueado'))}})")
    dlg.get_by_role('button',name='Copiar texto').click()
    chosen=dlg.locator('textarea');expect(chosen).to_be_visible()
    assert chosen.input_value()==copied and chosen.evaluate('el=>el.selectionEnd-el.selectionStart===el.value.length')
    dlg.get_by_role('button',name='Fechar').click()
    assert before==p.evaluate('key=>localStorage.getItem(key)',KEY)
    passed('documento de impressão isolado, PDF com texto conferido, cópia manual e carteira preservada')
    nav(p,'reports');p.locator('[data-action=resumo-cliente][data-id=a]').click()
    expect(dlg).to_contain_text('Empresa Alfa');p.keyboard.press('Escape');expect(dlg).to_have_count(0)
    nav(p,'clients');p.locator('[data-action=view-client][data-id=a]').click()
    p.locator('[data-action=resumo-cliente]').click();expect(dlg).to_contain_text('1.234,77');p.keyboard.press('Escape')
    nav(p,'dashboard');period.select_option('today')
    ag.locator('li').filter(has_text='Guia de hoje').get_by_role('button').click()
    expect(p.locator('#f-status')).to_have_value('paid');expect(p.locator('#f-paidAt')).to_have_value('2026-12-31')
    form(p,'tax',{});saved(p);expect(ag).not_to_contain_text('Guia de hoje')
    ag.locator('li').filter(has_text='Tarefa de hoje').get_by_role('button').click();expect(ag).not_to_contain_text('Tarefa de hoje')
    p.clock.fast_forward(12*3600*1000+1000);expect(ag).to_contain_text('Guia de janeiro')
    p.locator('#client-filter').select_option('b');period.select_option('all')
    expect(ag).to_contain_text('Só para Beta');expect(ag).not_to_contain_text('Guia de janeiro')
    p.locator('#month').fill('2026-09');p.locator('[data-action=resumo-cliente]').click()
    expect(sheet).to_contain_text('Nenhuma guia registrada');expect(sheet).to_contain_text('Notas emitidas (0)')
    expect(sheet).to_contain_text('Empresa Beta');expect(sheet).not_to_contain_text('Empresa Alfa');p.keyboard.press('Escape')
    passed('atalhos da ficha e do relatório, baixa de guia, conclusão de tarefa, virada do dia e competência vazia')
    p.set_viewport_size({'width':390,'height':844})
    assert p.evaluate('document.documentElement.scrollWidth<=innerWidth')
    p.locator('[data-action=resumo-cliente]').click();expect(dlg.get_by_role('button',name='Copiar texto')).to_be_visible()
    assert dlg.evaluate('el=>el.scrollWidth<=el.clientWidth+1')
    assert not errors,errors
    passed('agenda e resumo utilizáveis em viewport de 390 px')
    ctx.close()

def previous_version(browser,base,old):
    ctx=browser.new_context();p=ctx.new_page();url=base+'/'+servidor.LOCAL_HTML
    p.route(url,lambda r:r.fulfill(content_type='text/html',body=Path(old).read_bytes()))
    p.goto(url);nav(p,'clients');action(p,'new-client');form(p,'client',{'name':'Empresa migrada da 1.5'});saved(p)
    nav(p,'vault')
    vault_fill(p,'vault-setup-form',{'master':'Teste-privado-1.5!','confirm':'Teste-privado-1.5!'});expect(p.locator('.vault-ok')).to_be_visible()
    action(p,'vault-new');vault_fill(p,'vault-entry-form',{'label':'Sistema de teste','password':'Senha de teste do legado'});expect(p.locator('#vault-entry-form')).to_have_count(0)
    saved_value=p.evaluate('key=>localStorage.getItem(key)',KEY)
    p.unroute(url);p.goto(url);nav(p,'reports');p.locator('[data-action=resumo-cliente]').click()
    expect(p.locator('#resumo-mensal')).to_contain_text('Empresa migrada da 1.5');p.keyboard.press('Escape')
    nav(p,'vault');vault_fill(p,'vault-unlock-form',{'master':'Teste-privado-1.5!'});expect(p.locator('.vault-ok')).to_be_visible()
    action(p,'vault-edit');expect(p.locator('#vault-password')).to_have_value('Senha de teste do legado')
    assert saved_value==p.evaluate('key=>localStorage.getItem(key)',KEY)
    passed('carteira e cofre criados pela versão 1.5 mantidos byte a byte após consulta na 1.6')
    ctx.close()

if __name__=='__main__':
    args=argparse.ArgumentParser();args.add_argument('--html-v15');opt=args.parse_args()
    with servidor.ThreadingHTTPServer(('127.0.0.1',0),servidor.Handler) as server,sync_playwright() as pw:
        threading.Thread(target=server.serve_forever,daemon=True).start()
        browser=browser_start(pw);base='http://127.0.0.1:'+str(server.server_port)
        try:
            run(browser,base)
            if opt.html_v15:previous_version(browser,base,opt.html_v15)
        finally:browser.close();server.shutdown()
