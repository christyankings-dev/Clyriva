-- Somente em banco PostgreSQL descartável, sem Supabase. Dublê da identidade para testar RLS.
\set ON_ERROR_STOP on
do $$begin if current_database()<>'clyriva_auditoria' or to_regclass('auth.users') is not null then
  raise exception 'Use um banco novo e vazio chamado clyriva_auditoria'; end if;end$$;
do $$begin if not exists(select 1 from pg_roles where rolname='anon') then create role anon;end if;
  if not exists(select 1 from pg_roles where rolname='authenticated') then create role authenticated;end if;end$$;
create schema auth;
create table auth.users(id uuid primary key,email text,email_confirmed_at timestamptz);
create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
grant usage on schema auth to authenticated;
