do $$begin if current_database()<>'clyriva_auditoria' then raise exception 'Use o banco descartável de testes';end if;end$$;
insert into auth.users values ('10000000-0000-4000-8000-000000000001','titular-legado@example.test',now());
insert into public.clyriva_admins(user_id) select id from auth.users;
insert into public.clyriva_workspace(admin_id,payload) select id,'{"version":1,"clients":[{"id":"legado","name":"Cadastro legado","notes":"anotação interna","monthlyFee":120}],"invoices":[{"id":"pendente","clientId":"legado","status":"pending","value":100}],"cash":[],"fees":[],"tasks":[]}' from auth.users;
insert into public.clyriva_vault(admin_id,encrypted) select id,'{"version":1,"iterations":310000,"salt":"MDEyMzQ1Njc4OUFCQ0RFRg==","iv":"MDEyMzQ1Njc4OUFC","cipher":"MDEyMzQ1Njc4OUFCQ0RFRg=="}' from auth.users;
insert into public.clyriva_client_access(admin_id,client_id,email) select id,'legado','cliente-legado@example.test' from auth.users;
insert into public.clyriva_client_views(admin_id,client_id,info) select id,'legado','{"invoices":[{"id":"pendente"}]}' from auth.users;
create table public.auditoria_baseline as select w.admin_id,w.payload,v.encrypted from public.clyriva_workspace w join public.clyriva_vault v using (admin_id);
