"""Testes pelo navegador. python -m pip install playwright; python -m playwright install chromium.
Execute python tests/fluxos.py [--cnpj-real]. CHROMIUM_BIN permite selecionar outro Chromium."""
import argparse
import json
import os
import sys
import tempfile
import threading
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import servidor

def passed(label):
    print('OK '+label,flush=True)

def browser_start(p):
    options={'headless':True,'args':['--disable-dev-shm-usage','--disable-gpu']}
    if os.getenv('CHROMIUM_BIN'):
        options['executable_path']=os.environ['CHROMIUM_BIN']
    return p.chromium.launch(**options)

def form(page,kind,fields):
    box=page.locator('#edit-form')
    expect(box).to_have_attribute('data-type',kind)
    for name,value in fields.items():
        field=box.locator('[name="'+name+'"]')
        if field.evaluate('el=>el.tagName')=='SELECT':
            field.select_option(value)
        else:
            field.fill(value)
    box.locator('button[type=submit]').click()

def action(p,name):
    p.locator('[data-action="'+name+'"]').first.click()
def nav(p,name):
    p.locator('[data-page="'+name+'"]').click()
def saved(p):
    expect(p.locator('#edit-form')).to_have_count(0)
def state(p):
    return p.evaluate("JSON.parse(localStorage.getItem('carteira-meu-escritorio-v1'))")
def vault_fill(page,form_id,data):
    f=page.locator('#'+form_id)
    for k,v in data.items(): f.locator('[name="'+k+'"]').fill(v)
    f.locator('button[type=submit]').click()

def run(browser,base,do_live):
    local=base+'/'+servidor.LOCAL_HTML
    ctx=browser.new_context(accept_downloads=True)
    p=ctx.new_page(); errors=[]
    p.on('pageerror',lambda e:errors.append(str(e)))
    p.on('dialog',lambda d:d.accept())
    p.goto(local)
    for name in ('clients','invoices','cash','fees','taxes','tasks','reports','settings','dashboard'):
        nav(p,name);expect(p.locator('#page h1')).to_be_visible()
    passed('navegação dos módulos com carteira vazia')
    nav(p,'clients');action(p,'new-client')
    form(p,'client',{'name':'Escritório de teste A','monthlyFee':'280.45','notes':'reservado para auditoria'});saved(p)
    action(p,'new-client');form(p,'client',{'name':'Empresa de teste B','monthlyFee':'0'});saved(p)
    clients=state(p)['clients'];a,b=clients[0]['id'],clients[1]['id']
    p.locator('[data-action=edit-client][data-id="'+a+'"]').click();form(p,'client',{'name':'Cliente A revisado'});saved(p)
    assert state(p)['clients'][0]['name']=='Cliente A revisado'
    passed('cadastro e edição persistente de empresas')
    nav(p,'invoices');action(p,'new-invoice')
    form(p,'invoice',{'clientId':a,'number':'100','date':'2026-11-05','competence':'2026-11','value':'1234.56'});saved(p)
    p.locator('#month').fill('2026-11')
    action(p,'new-receipt-for');assert p.locator('#f-value').input_value()=='1234.56'
    form(p,'cash',{'value':'234.56','date':'2026-11-12'});saved(p)
    expect(p.locator('.kpis')).to_contain_text('1.000,00')
    action(p,'new-receipt-for');form(p,'cash',{'value':'1000.01'});expect(p.locator('.toast').last).to_contain_text('supera')
    action(p,'close-modal');action(p,'edit-invoice');form(p,'invoice',{'clientId':b})
    expect(p.locator('.toast').last).to_contain_text('Desvincule');action(p,'close-modal')
    passed('NF, recebimento parcial, saldo e bloqueios por excesso e troca de cliente')
    nav(p,'cash');action(p,'new-cash');form(p,'cash',{'clientId':a,'kind':'expense','date':'2026-11-09','category':'Despesa do teste','value':'34.56'});saved(p)
    nav(p,'taxes');action(p,'new-tax');form(p,'tax',{'clientId':a,'kind':'DARF','competence':'2026-11','dueDate':'2026-11-20','value':'45.67'});saved(p)
    action(p,'pay-tax');expect(p.locator('#f-status')).to_have_value('paid')
    form(p,'tax',{'paidAt':'2026-11-17'});saved(p);assert state(p)['taxes'][0]['status']=='paid'
    passed('caixa, guia e baixa com data de pagamento')
    nav(p,'fees');action(p,'fee-for');form(p,'fee',{'paid':'80.45','paidAt':'2026-11-11'});saved(p)
    action(p,'fee-for');form(p,'fee',{'paid':'100','paidAt':'2026-11-12'});saved(p)
    assert len(state(p)['fees'])==1 and state(p)['fees'][0]['paid']==100
    nav(p,'tasks');action(p,'new-task');form(p,'task',{'clientId':a,'title':'Conferir notas','competence':'2026-10','dueDate':'2026-10-31'});saved(p)
    action(p,'copy-tasks');action(p,'copy-tasks');assert len(state(p)['tasks'])==2 and state(p)['tasks'][1]['dueDate']=='2026-11-30'
    action(p,'complete-task');expect(p.locator('[data-action=complete-task]')).to_have_count(0);assert state(p)['tasks'][1]['status']=='done'
    passed('honorários por competência e tarefas recorrentes com ajuste de vencimento')
    nav(p,'reports');p.locator('#search').fill('revisado')
    with p.expect_download() as ev: action(p,'export-csv')
    csv=Path(ev.value.path()).read_text(encoding='utf-8-sig')
    assert '1234.56' in csv and '234.56' in csv and '34.56' in csv and '1000' in csv and 'Empresa de teste B' not in csv
    passed('relatório visual e CSV com filtro e valores conciliados')
    nav(p,'vault')
    vault_fill(p,'vault-setup-form',{'master':'Senha-mestra-de-teste!','confirm':'Senha-mestra-de-teste!'});expect(p.locator('.vault-ok')).to_be_visible()
    action(p,'vault-new');vault_fill(p,'vault-entry-form',{'label':'Sistema teste','username':'teste@example.test','password':'Segredo-local-de-teste!'});expect(p.locator('#vault-entry-form')).to_have_count(0)
    txt=json.dumps(state(p));assert 'Segredo-local-de-teste!' not in txt and 'Senha-mestra-de-teste!' not in txt
    action(p,'vault-lock');vault_fill(p,'vault-unlock-form',{'master':'senha-incorreta'});expect(p.locator('.toast').last).to_contain_text('incorreta')
    vault_fill(p,'vault-unlock-form',{'master':'Senha-mestra-de-teste!'});expect(p.locator('.vault-ok')).to_be_visible()
    action(p,'vault-change');vault_fill(p,'vault-change-form',{'master':'Nova-chave-de-teste!','confirm':'Nova-chave-de-teste!'});expect(p.locator('#vault-change-form')).to_have_count(0)
    p.reload();nav(p,'vault');vault_fill(p,'vault-unlock-form',{'master':'Nova-chave-de-teste!'});expect(p.locator('.vault-ok')).to_be_visible()
    action(p,'vault-edit');assert p.locator('#vault-password').input_value()=='Segredo-local-de-teste!';action(p,'close-modal')
    p.clock.install();action(p,'vault-edit');p.clock.fast_forward(601000)
    expect(p.locator('#vault-unlock-form')).to_be_visible();expect(p.locator('#vault-entry-form')).to_have_count(0)
    passed('bloqueio por inatividade também fecha a senha em edição')
    passed('Web Crypto, senha incorreta, bloqueio, troca da chave e releitura após recarga')
    nav(p,'settings')
    with p.expect_download() as ev:action(p,'backup')
    backup=Path(ev.value.path()).read_bytes()
    action(p,'clear');expect(p.locator('#breadcrumb')).to_have_text('Visão geral')
    assert not state(p)['clients'] and state(p)['cofreCriptografado'] is None
    nav(p,'settings');p.locator('#import-file').set_input_files({'name':'backup.json','mimeType':'application/json','buffer':backup})
    expect(p.locator('#breadcrumb')).to_have_text('Visão geral')
    restored=state(p);assert len(restored['clients'])==2 and restored['cofreCriptografado']['iterations']==600000
    tampered=json.loads(backup);tampered['cash'][0]['clientId']=b
    nav(p,'settings');p.locator('#import-file').set_input_files({'name':'bad.json','mimeType':'application/json','buffer':json.dumps(tampered).encode()})
    expect(p.locator('.toast').last).to_contain_text('Importação interrompida');assert state(p)==restored
    passed('backup, restauração atômica, rejeição de vínculo incorreto sem perda')
    q=ctx.new_page();q.goto(local);nav(q,'clients');action(q,'new-client')
    nav(p,'clients');action(p,'new-client');form(p,'client',{'name':'Alteração mais recente'});saved(p)
    form(q,'client',{'name':'Versão antiga'});expect(q.locator('.toast').last).to_contain_text('outra aba')
    assert len(state(p)['clients'])==3
    q.close();passed('proteção contra gravação de aba desatualizada')
    nav(p,'clients');action(p,'new-client')
    p.locator('#f-document').fill('12.ABC.345/01DE-34');expect(p.locator('#cnpj-lookup-status')).to_contain_text('inválido')
    assert p.evaluate("ClyrivaCore.validCnpj('12.ABC.345/01DE-35')")
    if do_live:
        p.locator('#f-document').fill('00.000.000/0001-91')
        expect(p.locator('#f-name')).to_have_value('BANCO DO BRASIL SA',timeout=27000)
        print('REAL formulário:',p.locator('[name=cnpjLookupSource]').input_value(),p.locator('#f-name').input_value(),p.locator('#f-city').input_value(),p.locator('[name=cnpjLookupAt]').input_value(),flush=True)
    # Apenas a primeira fonte falha deliberadamente. Na execução --cnpj-real, a segunda resposta é pública real.
    p.route('**/api/cnpj/brasilapi/*',lambda r:r.fulfill(status=503,body='{}'))
    if not do_live:
        p.route('**/api/cnpj/cnpjws/*',lambda r:r.fulfill(json={'razao_social':'TESTE DO CONTRATO','estabelecimento':{'cnpj':'00000000000191','cidade':{'nome':'Brasília'}}}))
    p.locator('#f-document').fill('00000000000191');action(p,'lookup-cnpj')
    expect(p.locator('[name=cnpjLookupSource]')).to_have_value('CNPJ.ws',timeout=18000)
    if do_live:
        assert p.locator('#f-name').input_value()=='BANCO DO BRASIL SA'
        print('REAL segunda fonte após falha controlada na primeira:',p.locator('[name=cnpjLookupSource]').input_value(),p.locator('[name=cnpjLookupAt]').input_value(),flush=True)
        available=[]
        for source in ('brasilapi','cnpjws'):
            r=p.request.get(base+'/api/cnpj/'+source+'/00000000000191',timeout=13000)
            if r.status==200:
                payload=r.json()
                assert payload['razao_social']=='BANCO DO BRASIL SA'
                available.append(source)
                print('REAL fonte:',source,r.status,payload['razao_social'],flush=True)
            else:
                print('FONTE EXTERNA INDISPONÍVEL:',source,r.status,flush=True)
        assert available,'As duas fontes estavam indisponíveis na verificação de rede.'
    p.locator('#f-document').fill('123');expect(p.locator('#lookup-cnpj')).to_be_enabled()
    expect(p.locator('[name=cnpjLookupSource]')).to_have_value('')
    passed('validação alfanumérica, segunda fonte e limpeza de origem ao trocar o documento')
    p.unroute('**/api/cnpj/brasilapi/*')
    p.unroute('**/api/cnpj/cnpjws/*')
    p.route('**/api/cnpj/brasilapi/*',lambda r:r.fulfill(json={'cnpj':'11222333000181','razao_social':'Resposta incompatível'}))
    p.route('**/api/cnpj/cnpjws/*',lambda r:r.fulfill(status=429,body='{}'))
    p.locator('#f-document').fill('00000000000191');action(p,'lookup-cnpj')
    expect(p.locator('#cnpj-lookup-status')).to_contain_text('Limite')
    expect(p.locator('#f-name')).to_have_value('');expect(p.locator('[name=cnpjLookupSource]')).to_have_value('')
    form(p,'client',{'name':'Cadastro manual sem consulta'});saved(p)
    passed('documento divergente da resposta é recusado, limite do provedor e cadastro manual')
    # Conferência da demonstração e do isolamento do cofre local na mesma origem.
    portal=ctx.new_page();portal.on('pageerror',lambda e:errors.append(str(e)));portal.goto(base+'/')
    portal.locator('#demo-admin').click();frame=portal.frame_locator('#admin-iframe')
    expect(frame.locator('#page h1')).to_be_visible()
    frame.locator('[data-page=vault]').click();expect(frame.locator('#vault-setup-form')).to_be_visible()
    portal.locator('#adm-access').click();expect(portal.locator('#invite-form')).to_be_visible()
    portal.locator('#signout').click();portal.locator('#demo-client').click();expect(portal.locator('#client-body h1')).to_contain_text('Aurora')
    portal.locator('#switch-company').select_option(index=1);expect(portal.locator('#client-body h1')).to_contain_text('Estúdio Verde')
    assert state(p)['cofreCriptografado']==restored['cofreCriptografado']
    passed('navegação e isolamento entre demonstrações, portal e cofre local')
    p.set_viewport_size({'width':390,'height':844});p.locator('#hamb').click();p.locator('[data-page=reports]').click()
    expect(p.locator('#page h1')).to_contain_text('Relatórios')
    assert p.evaluate('document.documentElement.scrollWidth<=innerWidth')
    passed('menu e largura de tela no celular')
    p.set_viewport_size({'width':1280,'height':900});p.locator('#month').fill('2026-11')
    nav(p,'invoices');action(p,'delete-invoice');expect(p.locator('[data-action=edit-invoice]')).to_have_count(0)
    assert len(state(p)['cash'])==2 and not state(p)['cash'][0]['invoiceId']
    action(p,'new-invoice');form(p,'invoice',{'clientId':a,'number':'C-1','value':'100','competence':'2026-11','status':'pending'});saved(p)
    action(p,'edit-invoice');form(p,'invoice',{'status':'issued'});saved(p)
    action(p,'edit-invoice');form(p,'invoice',{'status':'canceled'});saved(p)
    expect(p.locator('.kpis .kpi-value').nth(1)).to_contain_text('0,00')
    nav(p,'clients');p.locator('[data-action=edit-client][data-id="'+a+'"]').click();form(p,'client',{'status':'inactive'});saved(p)
    nav(p,'reports');expect(p.locator('.report-item').nth(2)).to_contain_text('100,00')
    nav(p,'clients');p.locator('[data-action=delete-client][data-id="'+a+'"]').click()
    expect(p.locator('[data-action=edit-client][data-id="'+a+'"]')).to_have_count(0)
    after=state(p);assert any(c['id']==b for c in after['clients']) and all(not after[k] for k in ('cash','invoices','fees','taxes','tasks'))
    passed('exclusão e cancelamento de NF, baixa desvinculada, honorário histórico e exclusão da empresa')
    assert not errors,errors
    ctx.close()

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--cnpj-real',action='store_true')
    args=parser.parse_args()
    with servidor.ThreadingHTTPServer(('127.0.0.1',0),servidor.Handler) as server:
        threading.Thread(target=server.serve_forever,daemon=True).start()
        with sync_playwright() as pw:
            browser=browser_start(pw)
            try:run(browser,'http://127.0.0.1:'+str(server.server_port),args.cnpj_real)
            finally:browser.close()
        server.shutdown()
