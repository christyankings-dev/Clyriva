"""Mede a construção do mesmo relatório nas duas versões usando uma carteira de carga."""
import argparse
import json
import statistics
import threading
from pathlib import Path
from playwright.sync_api import sync_playwright
from fluxos import ROOT,browser_start,servidor

def dataset():
    data={'version':1,'clients':[],'invoices':[],'cash':[],'fees':[],'taxes':[],'tasks':[]}
    for k in range(200):
        cid='c'+str(k);data['clients'].append({'id':cid,'name':'Empresa de carga '+str(k),'status':'active','monthlyFee':100})
        for j in range(12):
            iid=cid+'-'+str(j)
            data['invoices'].append({'id':iid,'clientId':cid,'competence':'2026-11','date':'2026-11-02','value':75,'status':'issued'})
            data['cash'].append({'id':'r'+iid,'clientId':cid,'invoiceId':iid,'date':'2026-11-07','value':25,'kind':'receipt'})
    return data

def main(old):
    with servidor.ThreadingHTTPServer(('127.0.0.1',0),servidor.Handler) as server,sync_playwright() as pw:
        threading.Thread(target=server.serve_forever,daemon=True).start()
        browser=browser_start(pw)
        for label,path in [('1.4',Path(old)),('1.5',ROOT/servidor.LOCAL_HTML)]:
            ctx=browser.new_context();p=ctx.new_page()
            ctx.add_init_script("localStorage.setItem('carteira-meu-escritorio-v1',"+json.dumps(json.dumps(dataset()))+");")
            url='http://127.0.0.1:'+str(server.server_port)+'/'+servidor.LOCAL_HTML
            p.route(url,lambda r:r.fulfill(content_type='text/html',body=path.read_bytes()))
            p.goto(url);p.locator('#month').fill('2026-11')
            sample=p.evaluate("""()=>{const times=[];for(let i=0;i<8;i++){
            document.querySelector('[data-page=fees]').click();const from=performance.now();
            document.querySelector('[data-page=reports]').click();
            const n=document.querySelectorAll('#page tbody tr').length;if(n!==200)throw Error('Linhas: '+n);
            times.push(performance.now()-from);}return times.slice(1)}""")
            print('v'+label,'mediana_ms',round(statistics.median(sample),1),'amostras_ms',[round(x,1) for x in sample],flush=True)
            ctx.close()
        browser.close();server.shutdown()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--html-v14',required=True);main(p.parse_args().html_v14)
