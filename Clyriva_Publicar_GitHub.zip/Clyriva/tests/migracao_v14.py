"""Verifica uma atualização integral no banco descartável clyriva_auditoria."""
import argparse
import subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--banco',required=True);p.add_argument('--schema-v14',required=True);p.add_argument('--psql',default='psql');args=p.parse_args()
cmd=[args.psql,'-Xq','-v','ON_ERROR_STOP=1',args.banco]
# O primeiro script exige um banco de teste vazio com nome específico.
for path in [root/'tests/preparar_banco.sql',Path(args.schema_v14),root/'tests/legado_base.sql',
             root/'schema.sql',root/'schema.sql',root/'tests/legado_verificar.sql',root/'tests/banco.sql']:
    subprocess.run(cmd+['-f',str(path)],check=True)
