"""Regressões do armazenamento antigo. Opcional: passe --html-v14 com o HTML local original."""
import argparse
import json
import threading
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
from fluxos import ROOT, servidor, browser_start, nav, action, form, saved, vault_fill, passed, state

def run(browser,base,legacy):
    ctx=browser.new_context();p=ctx.new_page();p.on('dialog',lambda d:d.accept())
    url=base+'/'+servidor.LOCAL_HTML
    if legacy:
        p.route(url,lambda r:r.fulfill(content_type='text/html',body=Path(legacy).read_bytes()))
        p.goto(url);nav(p,'clients');action(p,'new-client');form(p,'client',{'name':'Histórico da versão anterior','monthlyFee':'310'});saved(p)
        nav(p,'vault');vault_fill(p,'vault-setup-form',{'master':'Legado-310000-teste!','confirm':'Legado-310000-teste!'});expect(p.locator('.vault-ok')).to_be_visible()
        action(p,'vault-new');vault_fill(p,'vault-entry-form',{'label':'Portal antigo','password':'Segredo-antigo-de-teste!'});expect(p.locator('#vault-entry-form')).to_have_count(0)
        raw=p.evaluate("JSON.parse(localStorage.getItem('carteira-meu-escritorio-v1'))")
        blob=p.evaluate("JSON.parse(localStorage.getItem('clyriva-cofre-v1'))")
        assert blob['iterations']==310000
        p.unroute(url)
        p.goto(url);nav(p,'vault');vault_fill(p,'vault-unlock-form',{'master':'Legado-310000-teste!'});expect(p.locator('.vault-ok')).to_be_visible()
        action(p,'vault-edit');assert p.locator('#vault-password').input_value()=='Segredo-antigo-de-teste!';action(p,'close-modal')
        nav(p,'clients');action(p,'new-client');form(p,'client',{'name':'Cliente da nova versão'});saved(p)
        assert state(p)['clients'][0]==raw['clients'][0] and state(p)['cofreCriptografado']==blob
        passed('carteira e cofre produzidos pelo HTML v1.4 abrem e migram sem alteração dos dados originais')
        historical={**raw,'cofreCriptografado':blob};historical.pop('taxes',None)
        nav(p,'settings');p.locator('#import-file').set_input_files({'name':'historico.json','mimeType':'application/json','buffer':json.dumps(historical).encode()})
        expect(p.locator('#breadcrumb')).to_have_text('Visão geral');assert state(p)['taxes']==[] and state(p)['clients']==raw['clients']
        passed('backup compatível com versão anterior sem a lista de tributos')
        # Alterar um único byte impede a abertura com a chave correta.
        p.evaluate("""()=>{const k='carteira-meu-escritorio-v1',d=JSON.parse(localStorage[k]);let s=d.cofreCriptografado.cipher;d.cofreCriptografado.cipher=(s[0]==='A'?'B':'A')+s.slice(1);localStorage[k]=JSON.stringify(d)}""")
        p.reload();nav(p,'vault');vault_fill(p,'vault-unlock-form',{'master':'Legado-310000-teste!'});expect(p.locator('.toast').last).to_contain_text('corrompidos');expect(p.locator('.vault-ok')).to_have_count(0)
        passed('AES-GCM recusa conteúdo adulterado')
    p.goto(url)
    p.evaluate("localStorage.setItem('carteira-meu-escritorio-v1','arquivo interrompido')")
    p.reload();expect(p.locator('#panel-status')).to_contain_text('Não foi possível abrir')
    assert p.evaluate("localStorage.getItem('carteira-meu-escritorio-v1')")=='arquivo interrompido'
    with p.expect_download() as ev:p.get_by_text('Exportar conteúdo original para recuperação').click()
    assert json.loads(Path(ev.value.path()).read_bytes())['workspaceOriginal']=='arquivo interrompido'
    passed('dados locais ilegíveis permanecem recuperáveis')
    p.goto(base+'/admin.html');expect(p.locator('#panel-status')).to_contain_text('login')
    p.goto((ROOT/'index.html').as_uri());p.locator('#demo-admin').click();fr=p.frame_locator('#admin-iframe')
    expect(fr.locator('#page h1')).to_be_visible();fr.locator('[data-page=clients]').click();expect(fr.locator('#page h1')).to_contain_text('clientes',ignore_case=True)
    p.goto((ROOT/servidor.LOCAL_HTML).as_uri());nav(p,'clients');action(p,'new-client');form(p,'client',{'name':'Exemplo local por arquivo'});saved(p);p.reload();nav(p,'clients');expect(p.locator('#page')).to_contain_text('Exemplo local por arquivo')
    passed('admin direto exige login, demonstração e edição local abrem também por arquivo')
    ctx.close()

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--html-v14');args=parser.parse_args()
    with servidor.ThreadingHTTPServer(('127.0.0.1',0),servidor.Handler) as server:
        threading.Thread(target=server.serve_forever,daemon=True).start()
        with sync_playwright() as pw:
            browser=browser_start(pw)
            try:run(browser,'http://127.0.0.1:'+str(server.server_port),args.html_v14)
            finally:browser.close()
        server.shutdown()
