"""Integração isolada com Supabase Auth (GoTrue), PostgREST, PostgreSQL e SMTP de captura.
Os binários são informados por PG_BIN, GOTRUE_BIN, AUTH_MIGRATIONS e POSTGREST_BIN.
O PostgreSQL inicia em um diretório temporário novo. Nenhum projeto externo é usado."""
import base64
import contextlib
import email
import hashlib
import hmac
import html
import http.client
import json
import os
import queue
import re
import secrets
import socket
import socketserver
import subprocess
import tempfile
import threading
import time
import urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
from fluxos import ROOT, servidor, browser_start, form, saved, passed, vault_fill

def free_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1',0));return s.getsockname()[1]
def jwt(role,secret):
    enc=lambda b:base64.urlsafe_b64encode(b).decode().rstrip('=')
    payload=enc(b'{"alg":"HS256","typ":"JWT"}')+'.'+enc(json.dumps({'role':role,'iss':'supabase','exp':int(time.time())+3600}).encode())
    return payload+'.'+enc(hmac.new(secret.encode(),payload.encode(),hashlib.sha256).digest())
def wait_url(url,process):
    for _ in range(100):
        if process.poll() is not None:raise RuntimeError('Serviço encerrou durante a inicialização')
        try:
            with urllib.request.urlopen(url,timeout=.3):return
        except Exception:time.sleep(.1)
    raise RuntimeError('Serviço não respondeu: '+url)

class SMTP(socketserver.StreamRequestHandler):
    def handle(self):
        self.wfile.write(b'220 localhost auditoria\r\n')
        while line:=self.rfile.readline():
            cmd=line.split(b' ')[0].strip().upper()
            if cmd==b'DATA':
                self.wfile.write(b'354 Continue\r\n');parts=[]
                while (s:=self.rfile.readline()) and s!=b'.\r\n':parts.append(s)
                self.server.messages.put(b''.join(parts))
            elif cmd==b'QUIT':
                self.wfile.write(b'221 Bye\r\n');break
            self.wfile.write(b'250 localhost\r\n')

def mail_link(smtp):
    msg=email.message_from_bytes(smtp.messages.get(timeout=20))
    for part in msg.walk():
        if part.get_content_type() in ('text/plain','text/html'):
            body=part.get_payload(decode=True).decode('utf-8','replace')
            for link in re.findall(r'https?://[^<\s"]+',html.unescape(body)):
                if '/verify?' in link:return link
    raise ValueError('Link de confirmação/recuperação ausente no SMTP de teste')

def gateway(auth_port,rest_port,anon):
    class Gateway(servidor.Handler):
        def service(self):
            ports={'/auth/v1/':auth_port,'/rest/v1/':rest_port}
            prefix=next((prefix for prefix in ports if self.path.startswith(prefix)),None)
            if not prefix:return False
            conn=http.client.HTTPConnection('127.0.0.1',ports[prefix],timeout=10)
            try:
                body=self.rfile.read(int(self.headers.get('Content-Length',0)))
                headers={k:v for k,v in self.headers.items() if k.lower() not in ('host','connection','content-length','accept-encoding')}
                conn.request(self.command,'/'+self.path[len(prefix):],body,headers);r=conn.getresponse();out=r.read()
                self.send_response(r.status)
                for k,v in r.getheaders():
                    if k.lower() not in ('transfer-encoding','content-length','connection','server','date'):self.send_header(k,v)
                self.send_header('Content-Length',str(len(out)));self.end_headers()
                try:self.wfile.write(out)
                except (BrokenPipeError,ConnectionResetError):pass
            finally:conn.close()
            return True
        def do_GET(self):
            if self.path=='/config.js':
                cfg={'supabaseUrl':'http://127.0.0.1:'+str(self.server.server_port),'supabaseAnonKey':anon}
                self.send(200,('window.CLYRIVA_CONFIG='+json.dumps(cfg)+';').encode(),'text/javascript')
            elif not self.service():super().do_GET()
        def do_POST(self):self.service()
        do_PATCH=do_POST
        do_DELETE=do_POST
        do_PUT=do_POST
    return Gateway

def run_ui(browser,url,smtp,sql):
    admin=browser.new_context();pa=admin.new_page();client=browser.new_context();pc=client.new_page()
    errors=[];password=secrets.token_urlsafe(18)
    for p in (pa,pc):
        p.on('pageerror',lambda e:errors.append(str(e)))
        p.on('dialog',lambda d:d.accept())
    def signup(p,address):
        p.goto(url);p.locator('#btn-register').click()
        p.locator('[name=email]').fill(address);p.locator('[name=password]').fill(password)
        p.locator('#register-form button').click()
        expect(p.locator('#auth-feedback')).to_contain_text('Confirme')
        return mail_link(smtp)
    def login(p,address,pwd):
        p.goto(url);p.locator('#login-email').fill(address);p.locator('#login-pass').fill(pwd)
        p.locator('#auth-form button').click()
    link=signup(pa,'admin@example.test')
    pa.goto(link);expect(pa.locator('#client-body')).to_contain_text('Sem empresas')
    sql("insert into public.clyriva_admins(user_id) select id from auth.users where email='admin@example.test'")
    pa.locator('#signout').click();login(pa,'admin@example.test','credencial-errada')
    expect(pa.locator('#auth-feedback')).to_contain_text('Falha no login')
    login(pa,'admin@example.test',password);frame=pa.frame_locator('#admin-iframe')
    expect(frame.locator('#page h1')).to_be_visible();passed('Supabase Auth real, confirmação local, senha errada e rota administrativa')
    def new_client(name,doc=''):
        frame.locator('[data-page=clients]').click();frame.locator('[data-action=new-client]').first.click()
        form(frame,'client',{'name':name,'notes':'nota privada teste','document':doc});saved(frame)
    new_client('Empresa autorizada');new_client('Empresa reservada')
    frame.locator('[data-page=invoices]').click();frame.locator('[data-action=new-invoice]').first.click()
    m=frame.locator('#month').input_value()
    form(frame,'invoice',{'number':'AUT-1','value':'187.90','competence':m});saved(frame)
    today=pa.evaluate("()=>{const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')}")
    y,mo=map(int,m.split('-'))
    prior=f'{y-1}-12' if mo==1 else f'{y}-{mo-1:02d}'
    frame.locator('[data-page=taxes]').click();frame.locator('[data-action=new-tax]').first.click()
    frame.locator('#f-clientId').select_option(label='Empresa autorizada')
    form(frame,'tax',{'kind':'DARF','competence':prior,'dueDate':today,'value':'42.35'});saved(frame)
    frame.locator('[data-page=tasks]').click()
    for company,title in [('Empresa autorizada','Enviar extrato da empresa'),('Empresa reservada','Tarefa exclusiva de outra carteira')]:
        frame.locator('[data-action=new-task]').first.click();frame.locator('#f-clientId').select_option(label=company)
        form(frame,'task',{'title':title,'competence':m,'dueDate':today,'notes':'Observação interna da atividade'});saved(frame)
    frame.locator('[data-page=reports]').click()
    frame.locator('tr').filter(has_text='Empresa autorizada').locator('[data-action=resumo-cliente]').click()
    admin_summary=frame.locator('#resumo-mensal article')
    expect(admin_summary).to_contain_text('187,90')
    expected_sections=admin_summary.locator('section').all_inner_texts()
    frame.locator('#resumo-mensal').get_by_role('button',name='Fechar').click()
    frame.locator('[data-page=vault]').click()
    vault_fill(frame,'vault-setup-form',{'master':'Chave-online-de-teste!','confirm':'Chave-online-de-teste!'})
    expect(frame.locator('.vault-ok')).to_be_visible()
    vault_fill_new=frame.locator('[data-action=vault-new]').first;vault_fill_new.click()
    vault_fill(frame,'vault-entry-form',{'label':'teste integrado','password':'Senha-protegida-de-teste!'});expect(frame.locator('#vault-entry-form')).to_have_count(0)
    assert 'Senha-protegida-de-teste!' not in sql("select encrypted::text from public.clyriva_vault")
    assert pa.evaluate("localStorage.getItem('clyriva-cofre-v1')") is None
    pa.reload();frame=pa.frame_locator('#admin-iframe');frame.locator('[data-page=vault]').click()
    vault_fill(frame,'vault-unlock-form',{'master':'Chave-online-de-teste!'});expect(frame.locator('.vault-ok')).to_be_visible()
    passed('gravação real via PostgREST e recarga da carteira e do cofre')
    # Interrupção controlada apenas desta requisição. A nova tentativa usa o banco real.
    def offline_once(route):
        route.fulfill(status=503,json={'message':'Interrupção controlada no teste'})
    pa.route('**/rpc/clyriva_commit',offline_once)
    frame.locator('[data-page=clients]').click();frame.locator('[data-action=new-client]').first.click()
    form(frame,'client',{'name':'Cadastro após reconexão'});expect(frame.locator('.toast').last).to_contain_text('não salva')
    expect(frame.locator('#f-name')).to_have_value('Cadastro após reconexão')
    assert sql("select count(*) from public.clyriva_workspace w,jsonb_array_elements(w.payload->'clients') c where c->>'name'='Cadastro após reconexão'")=='0'
    pa.unroute('**/rpc/clyriva_commit',offline_once)
    form(frame,'client',{});saved(frame)
    passed('falha controlada preserva o formulário e a repetição grava no banco real')
    pa.locator('#adm-access').click();cid=pa.locator('#invite-client option').filter(has_text='Empresa autorizada').get_attribute('value')
    pa.locator('#invite-client').select_option(cid);pa.locator('#invite-email').fill('cliente@example.test');pa.locator('#invite-form button').click()
    expect(pa.locator('[data-toggle]')).to_be_visible()
    link=signup(pc,'cliente@example.test')
    login(pc,'cliente@example.test',password);expect(pc.locator('#auth-feedback')).to_contain_text('Falha no login')
    pc.goto(link);expect(pc.locator('#client-body h1')).to_have_text('Empresa autorizada')
    expect(pc.locator('#client-body')).to_contain_text('AUT-1')
    assert 'Empresa reservada' not in pc.locator('body').inner_text() and pc.locator('#switch-company').count()==0
    assert pc.locator('#admin-iframe').count()==0
    passed('conta de cliente confirmada, empresa autorizada e NF publicada')
    agenda=pc.locator('#agenda-vencimentos');agenda.locator('select').select_option('today')
    expect(agenda).to_contain_text('DARF');expect(agenda).to_contain_text('Enviar extrato da empresa')
    expect(agenda).not_to_contain_text('Tarefa exclusiva de outra carteira')
    assert agenda.locator('li button').count()==0
    pc.locator('#resumo-cliente').click()
    dlg=pc.locator('#resumo-mensal')
    assert dlg.locator('article section').all_inner_texts()==expected_sections
    for private in ('Empresa reservada','Observação interna da atividade','nota privada teste','Senha-protegida-de-teste!','DARF'):
        expect(dlg).not_to_contain_text(private)
    dlg.get_by_role('button',name='Imprimir / salvar PDF').click()
    expect(dlg.locator('iframe')).to_have_count(1)
    passed('agenda e resumo em duas sessões reais com privacidade, paridade e impressão individual')
    pa.locator('[data-toggle]').click();expect(pa.locator('[data-toggle]')).to_have_text('Reativar')
    pc.bring_to_front();pc.evaluate("window.dispatchEvent(new Event('online'))")
    expect(pc.locator('#client-body')).to_contain_text('Sem empresas')
    expect(pc.locator('#resumo-mensal')).to_have_count(0);expect(pc.locator('.routine-print-frame')).to_have_count(0)
    passed('suspensão recolhe o resumo aberto e seu documento de impressão na atualização do portal')
    pa.locator('[data-toggle]').click();expect(pa.locator('[data-toggle]')).to_have_text('Suspender')
    pc.reload();expect(pc.locator('#client-body h1')).to_have_text('Empresa autorizada')
    pa.locator('[data-revoke]').click();expect(pa.locator('[data-revoke]')).to_have_count(0)
    pc.reload();expect(pc.locator('#client-body')).to_contain_text('Sem empresas')
    passed('suspensão, reativação e revogação reais em navegadores separados')
    pc.locator('#signout').click();pc.locator('#login-email').fill('cliente@example.test');pc.locator('#btn-forgot').click()
    expect(pc.locator('#auth-feedback')).to_contain_text('link')
    link=mail_link(smtp);pc.goto(link);expect(pc.locator('#reset-form')).to_be_visible()
    newpass=secrets.token_urlsafe(18);pc.locator('#reset-form [name=password]').fill(newpass);pc.locator('#reset-form button').click()
    expect(pc.locator('#client-body')).to_be_visible();pc.locator('#signout').click()
    login(pc,'cliente@example.test',password);expect(pc.locator('#auth-feedback')).to_contain_text('Falha no login')
    login(pc,'cliente@example.test',newpass);expect(pc.locator('#client-body')).to_be_visible()
    passed('recuperação por link, nova senha e rejeição da senha anterior')
    pc.goto(url+'/?recuperar=1');expect(pc.locator('#auth-feedback')).to_contain_text('link de recuperação válido')
    assert pc.locator('#reset-form').count()==0
    passed('URL sem token de recuperação não abre a troca de senha de uma sessão existente')
    sibling=admin.new_page();sibling.goto(url);other=sibling.frame_locator('#admin-iframe');expect(other.locator('#page')).to_be_visible()
    pa.locator('#adm-panel').click();new_client('Gravação mais recente')
    other.locator('[data-action=new-client]').first.click();form(other,'client',{'name':'Versão concorrente'})
    expect(other.locator('.toast').last).to_contain_text('outra aba')
    assert sql("select count(*) from public.clyriva_workspace w, jsonb_array_elements(w.payload->'clients') c where c->>'name'='Versão concorrente'")=='0'
    pa.locator('#signout').click();expect(sibling.locator('#auth-form')).to_be_visible()
    passed('conflito concorrente via RPC e logout entre abas')
    assert not errors,errors
    admin.close();client.close()

def main():
    pg=Path(os.environ['PG_BIN']);auth=Path(os.environ['GOTRUE_BIN']).resolve();rest=Path(os.environ['POSTGREST_BIN']).resolve()
    mig=Path(os.environ['AUTH_MIGRATIONS']).resolve();secret=secrets.token_urlsafe(44)
    with tempfile.TemporaryDirectory() as td,contextlib.ExitStack() as stack:
        pgport,authport,restport=[free_port() for _ in range(3)]
        smtp=stack.enter_context(socketserver.ThreadingTCPServer(('127.0.0.1',0),SMTP));smtp.messages=queue.Queue()
        server=stack.enter_context(servidor.ThreadingHTTPServer(('127.0.0.1',0),gateway(authport,restport,jwt('anon',secret))))
        for srv in (server,smtp):
            threading.Thread(target=srv.serve_forever,daemon=True).start();stack.callback(srv.shutdown)
        url='http://127.0.0.1:'+str(server.server_port);db='postgresql://postgres@127.0.0.1:'+str(pgport)+'/postgres'
        def start(name,cmd,env=None):
            log=stack.enter_context(open(td+'/'+name+'.log','w+'))
            proc=subprocess.Popen(cmd,stdout=log,stderr=log,env=env,cwd=td)
            def stop():
                if proc.poll() is None:proc.terminate();proc.wait(timeout=8)
            stack.callback(stop)
            return proc
        def sql(statement,file=False):
            res=subprocess.run([pg/'psql','-XqAt',db,'-v','ON_ERROR_STOP=1','-f' if file else '-c',str(statement)],capture_output=True,text=True)
            if res.returncode:raise RuntimeError(res.stderr)
            return res.stdout.strip()
        subprocess.run([pg/'initdb','-D',td+'/pg','-U','postgres','-A','trust'],check=True,stdout=subprocess.DEVNULL)
        start('db',[pg/'postgres','-D',td+'/pg','-k','','-h','127.0.0.1','-p',str(pgport)])
        for _ in range(100):
            try:sql('select 1');break
            except RuntimeError:time.sleep(.1)
        sql("create role anon;create role authenticated;create schema auth;grant usage on schema auth to authenticated;create function auth.uid() returns uuid language sql stable as $$select (nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub')::uuid$$;")
        env={**os.environ,'API_EXTERNAL_URL':url,'GOTRUE_API_HOST':'127.0.0.1','GOTRUE_API_PORT':str(authport),
            'GOTRUE_SITE_URL':url+'/','GOTRUE_URI_ALLOW_LIST':url+'/**','GOTRUE_DB_DRIVER':'postgres','GOTRUE_DB_DATABASE_URL':db+'?search_path=auth,public',
            'DB_NAMESPACE':'auth','GOTRUE_DB_NAMESPACE':'auth','GOTRUE_DB_MIGRATIONS_PATH':str(mig),'GOTRUE_JWT_SECRET':secret,
            'GOTRUE_JWT_DEFAULT_GROUP_NAME':'authenticated','GOTRUE_JWT_AUD':'authenticated','GOTRUE_EXTERNAL_EMAIL_ENABLED':'true','GOTRUE_MAILER_AUTOCONFIRM':'false',
            'GOTRUE_SMTP_HOST':'127.0.0.1','GOTRUE_SMTP_PORT':str(smtp.server_address[1]),'GOTRUE_SMTP_ADMIN_EMAIL':'mailer@example.test',
            'GOTRUE_MAILER_URLPATHS_CONFIRMATION':'/auth/v1/verify','GOTRUE_MAILER_URLPATHS_RECOVERY':'/auth/v1/verify',
            'GOTRUE_SMTP_MAX_FREQUENCY':'1s','GOTRUE_RATE_LIMIT_EMAIL_SENT':'100'}
        try:
            (Path(td)/'migrations').symlink_to(mig,target_is_directory=True)
            migration=subprocess.run([auth,'migrate'],cwd=td,env=env,capture_output=True,text=True)
            if migration.returncode:raise RuntimeError('Migração Auth: '+(migration.stderr+migration.stdout)[-1400:])
            proc=start('auth',[auth,'serve'],env);wait_url('http://127.0.0.1:'+str(authport)+'/health',proc)
            sql(ROOT/'schema.sql',True)
            env={**os.environ,'PGRST_SERVER_HOST':'127.0.0.1','PGRST_SERVER_PORT':str(restport),'PGRST_DB_URI':db,'PGRST_DB_SCHEMAS':'public','PGRST_DB_ANON_ROLE':'anon','PGRST_JWT_SECRET':secret}
            proc=start('rest',[rest],env);wait_url('http://127.0.0.1:'+str(restport)+'/',proc)
            with sync_playwright() as pw:
                browser=browser_start(pw)
                try:run_ui(browser,url,smtp,sql)
                finally:browser.close()
        except Exception:
            # Registros de inicialização suficientes para identificar incompatibilidades de binários.
            for name in ('auth','rest'):
                path=Path(td)/(name+'.log')
                if path.exists():
                    for line in path.read_text().splitlines():
                        if any(k in line.lower() for k in ('fatal','migration failed','panic:','failed to connect')):print(line[:1000])
            raise

if __name__=='__main__':main()
