\set ON_ERROR_STOP on
begin;
do $$begin if current_database()<>'clyriva_auditoria' then raise exception 'Use banco descartável';end if;end$$;
create function pg_temp.ok(b boolean,label text) returns void language plpgsql as $$
begin if b is distinct from true then raise exception 'FALHOU: %',label;end if;raise notice 'OK %',label;end$$;
insert into auth.users values
 ('00000000-0000-4000-8000-000000000001','adm-a@example.test',now()),
 ('00000000-0000-4000-8000-000000000002','cliente-a@example.test',now()),
 ('00000000-0000-4000-8000-000000000003','sem-confirmacao@example.test',null),
 ('00000000-0000-4000-8000-000000000004','adm-b@example.test',now()),
 ('00000000-0000-4000-8000-000000000005','cliente-b@example.test',now());
insert into public.clyriva_admins(user_id) select id from auth.users where email like 'adm-%';
set local role authenticated;
set local request.jwt.claim.sub='00000000-0000-4000-8000-000000000001';
select pg_temp.ok(public.clyriva_load()->>'revision'='0','leitura inicial');
select '{"version":1,"clients":[{"id":"a","name":"Empresa A","monthlyFee":500,"notes":"privada","status":"active"},{"id":"b","name":"Empresa B","status":"active"}],"invoices":[{"id":"i","clientId":"a","status":"issued","value":200},{"id":"p","clientId":"a","status":"pending","value":100},{"id":"d","clientId":"a","status":"draft","value":100}],"cash":[{"id":"r","invoiceId":"i","clientId":"a","kind":"receipt","value":70}],"fees":[],"tasks":[{"id":"t","clientId":"a","title":"Pública","notes":"internas"}],"taxes":[]}' as payload \gset
select '{"version":1,"iterations":310000,"salt":"MDEyMzQ1Njc4OUFCQ0RFRg==","iv":"MDEyMzQ1Njc4OUFC","cipher":"MDEyMzQ1Njc4OUFCQ0RFRg=="}' as envelope \gset
select pg_temp.ok(public.clyriva_commit(0,:'payload',:'envelope')=1,'gravação de carteira + envelope + projeção');
insert into public.clyriva_client_access(admin_id,client_id,email) values
 (auth.uid(),'a','cliente-a@example.test'),(auth.uid(),'a','sem-confirmacao@example.test'),(auth.uid(),'b','cliente-b@example.test');
select pg_temp.ok((select count(*) from public.clyriva_client_views)=2,'administrador vê as duas empresas próprias');
set local request.jwt.claim.sub='00000000-0000-4000-8000-000000000002';
select pg_temp.ok((select count(*)=1 and min(client_id)='a' from public.clyriva_client_views),'cliente A só vê empresa A');
select pg_temp.ok((select not (info->'client' ?| array['notes','monthlyFee']) and not (info->'tasks'->0 ? 'notes')
  and not (info ?| array['cash','fees','vault']) from public.clyriva_client_views),'projeção exclui cofre, caixa, honorários e observações');
select pg_temp.ok((select jsonb_array_length(info->'invoices')=1 and info->'invoices'->0->>'paid'='70' from public.clyriva_client_views),'nota emitida e recebimento correto, previsões ocultas');
select pg_temp.ok((select count(*) from public.clyriva_workspace)=0 and (select count(*) from public.clyriva_vault)=0 and (select count(*) from public.clyriva_client_access)=0,'cliente sem leitura de dados privados');
select pg_temp.ok(public.clyriva_load() is null,'RPC de leitura administrativa isolada');
do $$begin perform public.clyriva_commit(0,'{}',null);raise exception 'gravou';exception when insufficient_privilege then raise notice 'OK cliente sem gravação na RPC';end$$;
select pg_temp.ok(not has_table_privilege('authenticated','public.clyriva_workspace','UPDATE') and not has_table_privilege('authenticated','public.clyriva_client_views','INSERT')
 and not has_table_privilege('authenticated','public.clyriva_admins','INSERT'),'escrita direta e autopromoção bloqueadas');
select pg_temp.ok(not has_function_privilege('anon','public.clyriva_commit(bigint,jsonb,jsonb)','EXECUTE')
 and not has_table_privilege('anon','public.clyriva_client_views','SELECT'),'anônimo sem acesso');
set local request.jwt.claim.sub='00000000-0000-4000-8000-000000000003';
select pg_temp.ok((select count(*) from public.clyriva_client_views)=0,'e-mail não confirmado sem acesso');
set local request.jwt.claim.sub='00000000-0000-4000-8000-000000000005';
select pg_temp.ok((select count(*)=1 and min(client_id)='b' from public.clyriva_client_views),'cliente B só vê empresa B');
set local request.jwt.claim.sub='00000000-0000-4000-8000-000000000004';
select pg_temp.ok((select count(*) from public.clyriva_workspace)=0 and (select count(*) from public.clyriva_client_views)=0,'administrador B sem acesso à carteira A');
select pg_temp.ok(public.clyriva_commit(0,'{"version":1,"clients":[{"id":"a","name":"Outra carteira"}],"invoices":[],"cash":[],"tasks":[],"fees":[],"taxes":[]}',null)=1,'mesmo ID de cliente em outra carteira permanece independente');
set local request.jwt.claim.sub='00000000-0000-4000-8000-000000000001';
do $$begin perform public.clyriva_commit(0,'{}',null);raise exception 'gravou';exception when serialization_failure then raise notice 'OK conflito de revisão';end$$;
do $$declare d jsonb;begin d:=public.clyriva_load()->'data';
  begin perform public.clyriva_commit(1,jsonb_set(d,'{cash,0,clientId}','"b"'),null);exception when raise_exception then if sqlerrm not like 'Vínculo de nota%' then raise;end if;raise notice 'OK vínculo entre empresas recusado';return;end;
  raise exception 'aceitou vínculo inválido';end$$;
select pg_temp.ok((public.clyriva_load()->>'revision')='1' and public.clyriva_load()->'vault' = :'envelope'::jsonb,'falha preserva carteira e envelope');
update public.clyriva_client_access set enabled=false where client_id='a' and email='cliente-a@example.test';
set local request.jwt.claim.sub='00000000-0000-4000-8000-000000000002';
select pg_temp.ok((select count(*) from public.clyriva_client_views)=0,'suspensão aplicada pelo banco');
set local request.jwt.claim.sub='00000000-0000-4000-8000-000000000001';
update public.clyriva_client_access set enabled=true where client_id='a' and email='cliente-a@example.test';
select pg_temp.ok(public.clyriva_commit(1,jsonb_set(:'payload','{clients,0,document}','"00.000.000/0001-91"'),:'envelope')=2,'alteração do documento do cliente');
select pg_temp.ok((select bool_and(not enabled) from public.clyriva_client_access where client_id='a'),'troca de identidade suspende a autorização anterior');
update public.clyriva_client_access set enabled=true where client_id='a' and email='cliente-a@example.test';
select pg_temp.ok(public.clyriva_commit(2,jsonb_set(:'payload','{clients,0,status}','"inactive"'),:'envelope')=3,'inativação da empresa');
select pg_temp.ok((select count(*) from public.clyriva_client_views)=1 and (select bool_and(not enabled) from public.clyriva_client_access where client_id='a'),'inativação suspende convites e recolhe publicação');
select pg_temp.ok(public.clyriva_commit(3,'{"version":1,"clients":[],"invoices":[],"cash":[],"tasks":[],"fees":[],"taxes":[]}',null)=4,'limpeza transacional');
select pg_temp.ok((select count(*) from public.clyriva_client_access)=0 and (select count(*) from public.clyriva_vault)=0 and (select count(*) from public.clyriva_client_views)=0,'remoção de autorizações órfãs, cofre e publicações');
rollback;
