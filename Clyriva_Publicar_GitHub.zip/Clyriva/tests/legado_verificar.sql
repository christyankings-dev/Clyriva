do $$begin if current_database()<>'clyriva_auditoria' then raise exception 'Use o banco descartável de testes';end if;end$$;
do $$begin
 if not exists(select 1 from public.auditoria_baseline b join public.clyriva_workspace w using(admin_id) join public.clyriva_vault v using(admin_id)
 join public.clyriva_client_views x using(admin_id) join public.clyriva_client_access g using(admin_id)
 where b.payload=w.payload and v.encrypted=b.encrypted and w.revision=0 and jsonb_array_length(x.info->'invoices')=0 and g.enabled and g.email='cliente-legado@example.test')
 then raise exception 'migração não preservou estado legado';end if;raise notice 'OK migração v1.4 com carteira, cofre, convite e retirada da nota prevista';end$$;
