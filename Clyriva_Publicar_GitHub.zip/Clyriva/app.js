/* Portal Clyriva. O painel administrativo mantém a carteira em memória durante a sessão. */
(()=>{'use strict';
const $=s=>document.querySelector(s), root=$('#root'), loginMarkup=root.innerHTML;
const core=window.ClyrivaCore, config=window.CLYRIVA_CONFIG||{};
const configured=Boolean(config.supabaseUrl || config.supabaseAnonKey);
let sb=null, configError='';
if(configured) {
  try {
    const url=new URL(config.supabaseUrl), key=String(config.supabaseAnonKey||'').trim();
    const loopback=u=>['localhost','127.0.0.1','[::1]'].includes(u.hostname);
    const safe=u=>u.protocol==='https:' || (u.protocol==='http:'&&loopback(u));
    if(!safe(url)||url.username||url.password||!safe(location)) throw Error('Use HTTPS no portal e no projeto. Para testes locais, use localhost.');
    let isPublic=key.startsWith('sb_publishable_');
    if(!isPublic && key.split('.').length===3) {
      try {isPublic=JSON.parse(atob(key.split('.')[1].replace(/-/g,'+').replace(/_/g,'/'))).role==='anon';} catch {}
    }
    if(!isPublic)throw Error('Informe somente a chave pública publishable ou anon do projeto em config.js.');
    sb=window.supabase.createClient(url.origin,key,{auth:{autoRefreshToken:true,persistSession:true,detectSessionInUrl:true}});
  }catch(e){configError=e.message;}
}
const blank=core.empty, {brl,sum,dateLabel:dbr,monthLabel:mon}=core;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ym=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');};
const errMsg=e=>e?.message||'Não foi possível concluir esta operação.';
let portalPoll=null, epoch=0, routeGeneration=0, pollBusy=false;
let awaitingRecovery=new URLSearchParams(location.hash.slice(1)).get('type')==='recovery'||new URLSearchParams(location.search).has('recuperar');
let recovering=false;
const redirectURL=()=>new URL(location.pathname,location.href).href;
const rotina=window.ClyrivaRotina;
let agendaView=rotina.agendaView();
const viewKey=row=>JSON.stringify([row.admin_id,row.client_id]);
const state={mode:'login',user:null,adminPayload:blank(),vault:null,revision:0,clientViews:[],access:[],month:ym(),selectedClient:null,adminTab:'panel',frame:null,saving:false,authBusy:false};
function discard(){
  rotina.closeSummary();agendaView=rotina.agendaView();
  epoch++;routeGeneration++;clearInterval(portalPoll);pollBusy=false;
  Object.assign(state,{mode:'login',user:null,adminPayload:blank(),vault:null,revision:0,clientViews:[],access:[],month:ym(),selectedClient:null,adminTab:'panel',frame:null,saving:false});
}
function assertCurrent(token){
  if(token!==epoch)throw Error('A sessão mudou. Entre novamente para continuar.');
}
async function readAll(table,columns,order,admin){
  const token=epoch,rows=[],pageSize=250;
  for(let start=0;;){
    let q=sb.from(table).select(columns);
    if(admin)q=q.eq('admin_id',admin);
    for(const col of order)q=q.order(col);
    const res=await q.range(start,start+pageSize-1);
    assertCurrent(token);if(res.error)throw res.error;
    if(!res.data.length)return rows;rows.push(...res.data);start+=res.data.length;
  }
}
const demoPayload=()=>{
 const c1='demo-cliente-01',c2='demo-cliente-02',m=ym();
 return {version:1,clients:[{id:c1,name:'Aurora Soluções Ltda',tradeName:'Aurora Soluções',document:'12.345.678/0001-90',status:'active',regime:'Simples Nacional',segment:'Prestação de serviços',email:'financeiro@aurora.exemplo',contactName:'Mariana Lopes',monthlyFee:300,priority:'high',city:'Goiânia',uf:'GO',notes:'DADOS FICTÍCIOS — exemplo do painel'},{id:c2,name:'Estúdio Verde ME',tradeName:'Estúdio Verde',document:'98.765.432/0001-10',status:'active',regime:'MEI',segment:'Serviços',email:'contato@estudioverde.exemplo',monthlyFee:180,priority:'medium',notes:'DADOS FICTÍCIOS'}],invoices:[{id:'inv1',clientId:c1,competence:m,number:'NF-125',date:m+'-04',value:5800,status:'issued',description:'Serviços mensais'},{id:'inv2',clientId:c1,competence:m,number:'NF-126',date:m+'-13',value:2700,status:'issued',description:'Consultoria'},{id:'inv3',clientId:c2,competence:m,number:'NF-041',date:m+'-09',value:3500,status:'issued',description:'Serviços prestados'}],cash:[{id:'cash1',clientId:c1,kind:'receipt',date:m+'-16',value:5800,invoiceId:'inv1',category:'Recebimento'},{id:'cash2',clientId:c2,kind:'receipt',date:m+'-14',value:3500,invoiceId:'inv3',category:'Recebimento'}],fees:[{id:'fee1',clientId:c1,competence:m,expected:300,paid:300,paidAt:m+'-05'},{id:'fee2',clientId:c2,competence:m,expected:180,paid:0}],taxes:[{id:'tax1',clientId:c1,kind:'DAS',competence:m,dueDate:m+'-20',value:510,status:'open'},{id:'tax2',clientId:c2,kind:'DAS',competence:m,dueDate:m+'-20',value:85,status:'paid'}],tasks:[{id:'task1',clientId:c1,title:'Enviar comprovantes do mês',category:'Documentos',competence:m,dueDate:m+'-23',status:'pending',priority:'medium'},{id:'task2',clientId:c1,title:'Conferir notas fiscais',category:'Fiscal',competence:m,dueDate:m+'-25',status:'progress',priority:'medium'},{id:'task3',clientId:c2,title:'Conferir DAS',category:'Fiscal',competence:m,dueDate:m+'-20',status:'done',priority:'medium'}]};
};
function sanitize(client,d){
 const safeClient={};
 for(const k of ['name','tradeName','document','regime','segment','status','activityCode','registryStatus','legalNature','companySize','openingDate','address','city','uf','zipCode','email','phone','contactName'])if(client[k]!==undefined)safeClient[k]=client[k];
 const invoices=d.invoices.filter(x=>x.clientId===client.id&&['issued','canceled'].includes(x.status)).map(x=>({id:x.id,number:x.number,date:x.date,competence:x.competence,value:x.value,status:x.status,description:x.description||'',paid:sum(d.cash.filter(p=>p.invoiceId===x.id&&p.clientId===client.id&&p.kind==='receipt'),p=>p.value)}));
 const taxes=(d.taxes||[]).filter(x=>x.clientId===client.id).map(x=>({id:x.id,kind:x.kind,competence:x.competence,value:x.value,status:x.status,dueDate:x.dueDate,paidAt:x.paidAt||''}));
 const tasks=d.tasks.filter(x=>x.clientId===client.id).map(x=>({id:x.id,title:x.title,category:x.category,competence:x.competence,dueDate:x.dueDate,status:x.status}));
 return {client:safeClient,invoices,taxes,tasks,publishedAt:new Date().toISOString()};
}
const snapshotRows=d=>(d.clients||[]).filter(c=>c.status!=='inactive').map(c=>({admin_id:state.user?.id,client_id:c.id,info:sanitize(c,d),published_at:new Date().toISOString()}));
function statusMessage(text,type=''){const el=$('#auth-feedback');if(el)el.innerHTML=`<div class="notice ${type}">${esc(text)}</div>`;}
function authPage(){state.mode='login';root.innerHTML=loginMarkup;wireLogin();}
function wireLogin(){
 $('#demo-panel').classList.toggle('hidden',configured);$('#local-entry').hidden=configured;
 $('#auth-form').addEventListener('submit',async e=>{
  e.preventDefault();if(!sb)return statusMessage(configError||'Para ativar logins reais, configure config.js e o banco de dados.', 'warn');
  const email=$('#login-email').value.trim().toLowerCase(),password=$('#login-pass').value;
  if(state.authBusy)return;if(awaitingRecovery){awaitingRecovery=false;history.replaceState({},'',redirectURL());}state.authBusy=true;const btn=$('#auth-form button[type="submit"]');btn.disabled=true;btn.textContent='Validando acesso…';
  try{const {error}=await sb.auth.signInWithPassword({email,password});if(error)throw error;await routeUser();}
  catch(err){statusMessage('Falha no login: '+errMsg(err),'err')}finally{state.authBusy=false;if(btn.isConnected){btn.disabled=false;btn.textContent='Entrar na minha conta →'}}
 });
 $('#btn-register').onclick=()=>registerPage();
 $('#btn-forgot').onclick=async()=>{if(!sb)return statusMessage('Configure o Supabase para recuperar senhas reais.','warn');const email=$('#login-email').value.trim().toLowerCase();if(!email)return statusMessage('Informe seu e-mail no campo acima para receber o link.','warn');try{const {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:redirectURL()+'?recuperar=1'});statusMessage(error?'Não foi possível enviar: '+error.message:'Caso o e-mail esteja cadastrado, você receberá um link para redefinir a senha.',error?'err':'')}catch(e){statusMessage(errMsg(e),'err')}};
 $('#demo-admin').onclick=()=>startDemo('admin');$('#demo-client').onclick=()=>startDemo('client');
 if(!configured)statusMessage('Modo demonstração disponível. Para autenticação real é necessário configurar o projeto Supabase.','warn');
 else if(!sb)statusMessage(configError||'Não foi possível carregar a biblioteca de autenticação.','err');
}
function registerPage(){
 const cont=$('.login-card');cont.innerHTML=`<span class="eyebrow">Cadastro de acesso</span><h2>Criar sua conta</h2><p style="margin:10px 0 22px">O cadastro não concede privilégios automaticamente. Administradores são autorizados pelo dono do banco; clientes precisam de convite por e-mail.</p><form id="register-form"><div><label class="form-label">E-mail</label><input class="field" name="email" type="email" autocomplete="username" required></div><div><label class="form-label">Crie uma senha</label><input class="field" name="password" type="password" minlength="8" autocomplete="new-password" required></div><button class="button">Cadastrar e confirmar meu e-mail</button></form><div id="auth-feedback" role="status"></div><button class="button secondary mt20" id="back-login">Voltar ao login</button>`;
 $('#back-login').onclick=authPage;
 $('#register-form').onsubmit=async e=>{e.preventDefault();if(!sb)return statusMessage('Configure o Supabase antes de cadastrar contas.','warn');const f=e.currentTarget;const email=f.elements.namedItem('email').value.trim().toLowerCase(),password=f.elements.namedItem('password').value;const b=f.querySelector('button');b.disabled=true;try{const {error}=await sb.auth.signUp({email,password,options:{emailRedirectTo:redirectURL()}});if(error)throw error;statusMessage('Cadastro enviado. Confirme seu e-mail e aguarde a autorização de acesso pelo administrador.')}catch(err){statusMessage(errMsg(err),'err')}finally{b.disabled=false}};
}
function resetPasswordPage(){const cont=$('.login-card');if(!cont)return;cont.innerHTML=`<span class="eyebrow">Segurança</span><h2>Definir nova senha</h2><p style="margin:10px 0 22px">Você acessou um link de recuperação. Defina uma senha nova.</p><form id="reset-form"><label class="form-label">Nova senha<input class="field" name="password" type="password" minlength="8" autocomplete="new-password" required></label><button class="button">Salvar nova senha</button></form><div id="auth-feedback"></div>`;$('#reset-form').onsubmit=async e=>{
 e.preventDefault();const b=e.target.querySelector('button');b.disabled=true;
 try{const result=await sb.auth.updateUser({password:e.target.elements.password.value});if(result.error)throw result.error;
 recovering=false;history.replaceState({},'',redirectURL());await routeUser();}
 catch(err){statusMessage(errMsg(err),'err');}finally{b.disabled=false;}
};}
async function startDemo(role){
 if(configured)return;
 if(role==='admin' && location.protocol==='file:' && !window.ClyrivaFileShell){
   try{await new Promise((ok,fail)=>{const script=document.createElement('script');script.src='file-demo.js';script.onload=ok;script.onerror=fail;document.head.append(script);});}
   catch{return statusMessage('Extraia o ZIP completo para abrir a demonstração.','err');}
 }
 discard();state.user=null;state.mode=role==='admin'?'demo-admin':'demo-client';state.adminPayload=demoPayload();state.selectedClient=state.adminPayload.clients[0].id;state.clientViews=snapshotRows(state.adminPayload);state.clientViews.forEach(x=>x.admin_id='demo');if(role==='admin')renderAdmin();else renderClient();}
function brandSidebar(){return `<div><div class="brand"><span class="brand-logo">C</span><span>Cly<em>riva</em></span></div><div class="brand-sub">Portal contábil</div></div>`}
function adminShell(){const demo=state.mode==='demo-admin';return `<div class="admin-app"><header class="header admin-top"><div class="row" style="gap:10px"><span class="brand-logo" style="height:32px;width:32px;font-size:21px">C</span><div><strong>Clyriva · Administração</strong><small>${esc(state.user?.email||'Demonstração administrativa')}</small></div></div><nav class="actions"><button class="button ${state.adminTab==='panel'?'':'secondary'} sm" id="adm-panel">▦ Painel completo</button><button class="button ${state.adminTab==='access'?'':'secondary'} sm" id="adm-access">♙ Acesso dos clientes</button></nav><div class="hdr-right"><span id="sync-state" class="pill ${demo?'warning':''}">${demo?'DEMONSTRAÇÃO':'Conectado'}</span><button class="button secondary sm" id="signout">Sair</button></div></header><div id="admin-body"></div></div>`}
function renderAdmin(){
  root.innerHTML=adminShell();
  $('#adm-panel').onclick=()=>{if(!state.saving&&state.adminTab!=='panel'){state.adminTab='panel';renderAdmin();}};
  $('#adm-access').onclick=()=>{if(!state.saving&&state.adminTab!=='access'){state.adminTab='access';renderAdmin();}};
  $('#signout').onclick=signout;state.frame=null;
  if(state.adminTab==='access'){
    renderAccess();
    if(state.mode==='admin'){
      const token=epoch;
      readAll('clyriva_client_access','admin_id,client_id,email,enabled,created_at',['client_id','email'],state.user.id)
        .then(rows=>{if(token===epoch && state.adminTab==='access' && JSON.stringify(rows)!==JSON.stringify(state.access)){state.access=rows;renderAccess();}})
        .catch(e=>{const fb=$('#invite-feedback');if(token===epoch&&fb)fb.textContent='Falha ao atualizar as permissões. '+errMsg(e);});
    }
    return;
  }
  const demo=state.mode==='demo-admin', host=$('#admin-body');
  host.innerHTML=demo?'<div class="admin-info warning">Demonstração com dados fictícios. As alterações duram apenas nesta sessão.</div>':'<div class="admin-info">Carteira privada. O indicador acima confirma a gravação no banco.</div>';
  const frame=document.createElement('iframe');frame.id='admin-iframe';frame.className='admin-view';frame.title='Painel administrativo Clyriva';state.frame=frame;
  if(demo && location.protocol==='file:' && window.ClyrivaFileShell)frame.srcdoc=window.ClyrivaFileShell;
  else frame.src='admin.html';
  host.append(frame);
}
function activePanel(child){
  return ['admin','demo-admin'].includes(state.mode) && state.adminTab==='panel' && state.frame?.contentWindow===child;
}
function syncLabel(text,bad=false){
  const el=$('#sync-state');if(el){el.textContent=text;el.className='pill '+(bad?'rose':'');}
  for(const id of ['adm-panel','adm-access','signout']){const b=$('#'+id);if(b)b.disabled=state.saving;}
}
Object.defineProperty(window,'ClyrivaPanelHost',{value:Object.freeze({
  open(child){
    if(!activePanel(child))return null;
    return structuredClone({data:state.adminPayload,vault:state.vault,demo:state.mode==='demo-admin'});
  },
  async commit(child,payload,vault){
    if(!activePanel(child)||state.saving)throw Error('Painel indisponível ou outra operação em andamento.');
    const data=core.workspace(structuredClone(payload)),blob=core.vault(structuredClone(vault)),token=epoch;
    const demo=state.mode==='demo-admin';
    state.saving=true;syncLabel('Salvando…');let saved=false;
    try{
      if(!demo){
        const res=await sb.rpc('clyriva_commit',{p_expected:state.revision,p_workspace:data,p_vault:blob});
        assertCurrent(token);if(res.error)throw Error(res.error.message);
        if(!Number.isSafeInteger(res.data)||res.data<=state.revision)throw Error('O banco não confirmou a revisão. Recarregue para conferir.');
        state.revision=res.data;
      }
      state.adminPayload=data;state.vault=blob;saved=true;
      const enabled=new Map(data.clients.map(c=>[c.id,c.status!=='inactive']));
      state.access=state.access.filter(a=>enabled.has(a.client_id)).map(a=>({...a,enabled:a.enabled && enabled.get(a.client_id)}));
    }finally{
      if(token===epoch){state.saving=false;syncLabel(saved?(demo?'DEMONSTRAÇÃO':'Sincronizado'):'Falha na gravação',!saved);}
    }
  }
})});
async function loadAdmin(user,token,generation){
  const [res,access]=await Promise.all([
    sb.rpc('clyriva_load'),
    readAll('clyriva_client_access','admin_id,client_id,email,enabled,created_at',['client_id','email'],user.id)
  ]);
  assertCurrent(token);if(generation!==routeGeneration)return;
  if(res.error)throw res.error;
  if(!res.data || !Number.isSafeInteger(res.data.revision))throw Error('Verifique o schema.sql e a confirmação do e-mail administrativo.');
  state.adminPayload=core.workspace(res.data.data??blank());state.vault=core.vault(res.data.vault);
  state.revision=res.data.revision;state.access=access;state.mode='admin';state.adminTab='panel';renderAdmin();
}
async function republish(){
  const token=epoch;
  const res=await sb.rpc('clyriva_republish',{p_expected:state.revision});
  assertCurrent(token);if(res.error)throw res.error;
  state.access=await readAll('clyriva_client_access','admin_id,client_id,email,enabled,created_at',['client_id','email'],state.user.id);
}
function renderAccess(){if(state.adminTab!=='access'||!['admin','demo-admin'].includes(state.mode)||!$('#admin-body'))return;const host=$('#admin-body'),d=state.adminPayload,cs=d.clients||[];
 host.innerHTML=`<div class="invite-area"><div class="pagehead"><div><span class="eyebrow">Permissões</span><h1>Portal dos clientes</h1><p>Vincule o e-mail autorizado a uma empresa. Você pode suspender ou excluir cada acesso.</p></div><button class="button secondary" id="refresh-public">↻ Atualizar portais</button></div>
 <div class="notice mb20"><strong>O que o cliente vê?</strong> Dados cadastrais, notas fiscais emitidas, guias e tarefas da própria empresa. <strong>Não vê:</strong> cofre, senhas, anotações internas, seus honorários, prioridades nem informações de outros clientes. A senha do login é definida pelo próprio cliente no cadastro.</div>
 <div class="panel pad mb20"><div class="panel-title">Liberar um novo acesso</div><p class="sub">O cliente deverá criar a conta com este mesmo e-mail e confirmar o endereço. O convite abaixo não envia e-mail automaticamente.</p>
 <form id="invite-form" class="invite-form"><div><label class="form-label">Empresa / cliente</label><select class="field" id="invite-client" required><option value="">Selecione um cliente</option>${cs.filter(c=>c.status!=='inactive').map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('')}</select></div><div><label class="form-label">E-mail autorizado</label><input class="field" type="email" id="invite-email" placeholder="cliente@empresa.com.br" required></div><button class="button" type="submit">+ Liberar acesso</button></form><div id="invite-feedback" class="mt20" role="status"></div></div>
 <div class="panel"><div class="pad row between"><div><div class="panel-title">Pessoas com acesso autorizado</div><p class="sub">${state.access.length} autorização(ões) nesta carteira</p></div></div><div class="table-wrap"><table class="table"><thead><tr><th>Empresa</th><th>E-mail do cliente</th><th>Situação</th><th>Ações</th></tr></thead><tbody>${state.access.length?state.access.map(a=>`<tr><td><strong>${esc(cs.find(c=>c.id===a.client_id)?.name||'Cliente removido')}</strong></td><td>${esc(a.email)}</td><td><span class="badge ${a.enabled?'ok':'pending'}">${a.enabled?'Liberado':'Suspenso'}</span></td><td><button class="button secondary sm" data-toggle="${esc(a.client_id)}" data-email="${esc(a.email)}">${a.enabled?'Suspender':'Reativar'}</button> <button class="button danger sm" data-revoke="${esc(a.client_id)}" data-email="${esc(a.email)}">Remover</button></td></tr>`).join(''):`<tr><td colspan="4">Nenhum cliente autorizado por enquanto.</td></tr>`}</tbody></table></div></div>
 <p class="footer-note">Acesso é concedido somente após verificação do e-mail pelo Supabase Auth. As permissões são aplicadas diretamente ao banco de dados, via RLS.</p></div>`;
 $('#invite-form').onsubmit=inviteClient;$('#refresh-public').onclick=async()=>{if(state.mode==='demo-admin'){alert('Demonstração: portais fictícios atualizados.');return}try{await republish();renderAccess();alert('Portais atualizados.')}catch(e){alert('Erro ao atualizar: '+errMsg(e))}};
 host.querySelectorAll('[data-toggle]').forEach(b=>b.onclick=()=>toggleAccess(b.dataset.toggle,b.dataset.email));host.querySelectorAll('[data-revoke]').forEach(b=>b.onclick=()=>revokeAccess(b.dataset.revoke,b.dataset.email));
}
async function inviteClient(ev){ev.preventDefault();const token=epoch;const clientId=$('#invite-client').value,email=$('#invite-email').value.trim().toLowerCase();const fb=$('#invite-feedback');if(!clientId||!email)return;
 if(state.access.some(a=>a.client_id===clientId&&a.email===email)){fb.innerHTML='<div class="notice warn">Este e-mail já está autorizado para essa empresa.</div>';return}
 if(state.mode==='demo-admin'){state.access.push({admin_id:'demo',client_id:clientId,email,enabled:true});renderAccess();return;}
 const {error}=await sb.from('clyriva_client_access').insert({admin_id:state.user.id,client_id:clientId,email,enabled:true});if(token!==epoch)return;if(error){fb.innerHTML=`<div class="notice err">${esc(error.message)}</div>`;return}state.access.push({admin_id:state.user.id,client_id:clientId,email,enabled:true});renderAccess();}
async function toggleAccess(id,email){const token=epoch;const a=state.access.find(x=>x.client_id===id&&x.email===email);if(!a)return;const enabled=!a.enabled;
 if(state.mode==='admin'){const {error}=await sb.from('clyriva_client_access').update({enabled}).eq('admin_id',state.user.id).eq('client_id',id).eq('email',email);if(token!==epoch)return;if(error)return alert(errMsg(error))}
 a.enabled=enabled;renderAccess();}
async function revokeAccess(id,email){const token=epoch;if(!confirm(`Revogar o acesso de ${email} a esta empresa?`))return;if(state.mode==='admin'){const {error}=await sb.from('clyriva_client_access').delete().eq('admin_id',state.user.id).eq('client_id',id).eq('email',email);if(token!==epoch)return;if(error)return alert(errMsg(error))}state.access=state.access.filter(x=>x.client_id!==id||x.email!==email);renderAccess();}
function badgeStatus(s){const x=String(s||'').toLowerCase();const tone=x==='paid'||x==='done'||x==='issued'?'ok':x==='canceled'?'red':'pending';return `<span class="badge ${tone}">${esc(({paid:'Pago',done:'Concluída',issued:'Emitida',pending:'Pendente',open:'Em aberto',progress:'Em andamento',canceled:'Cancelada'})[x]||s||'—')}</span>`}
function chosen(){return state.clientViews.find(x=>viewKey(x)===state.selectedClient)||state.clientViews[0]}
function clientShell(){return `<div class="shell"><aside class="side">${brandSidebar()}<h4>Área do cliente</h4><nav><button class="nav active">▦ &nbsp; Minha empresa</button></nav><div class="side-foot"><strong>${esc(state.user?.email||'Cliente • demonstração')}</strong><span>Visualização individual</span><button id="signout">Sair da conta</button></div></aside><div class="main"><header class="header"><div><strong>Portal do cliente</strong><small>Informações disponibilizadas pelo seu atendimento contábil</small></div><div class="hdr-right"><span class="pill ${state.mode==='demo-client'?'warning':''}">${state.mode==='demo-client'?'DEMONSTRAÇÃO':'Área do cliente'}</span></div></header><main id="client-body" class="content"></main></div></div>`}
function renderClient(){rotina.closeSummary();root.innerHTML=clientShell();$('#signout').onclick=signout;const host=$('#client-body');
 if(!state.clientViews.length){host.innerHTML=`<div class="empty panel"><b>Sem empresas disponíveis para esta conta</b><p>Confirme seu e-mail e peça ao administrador para liberar o acesso ao mesmo endereço. Caso já tenha autorização, saia e entre novamente.</p></div>`;return}
 const row=chosen();if(!row)return;if(state.selectedClient!==viewKey(row))agendaView=rotina.agendaView();state.selectedClient=viewKey(row);const info=row.info||{},c=info.client||{},m=state.month;
 const invoices=(info.invoices||[]).filter(x=>x.competence===m),taxes=(info.taxes||[]).filter(x=>x.competence===m),tasks=(info.tasks||[]).filter(x=>x.competence===m);
 const billing=sum(invoices.filter(x=>x.status==='issued'),x=>x.value),open=sum(invoices.filter(x=>x.status==='issued'),x=>Math.max(0,(Number(x.value)||0)-(Number(x.paid)||0)));
 const taxOpen=sum(taxes.filter(x=>x.status!=='paid'),x=>x.value),taskOpen=tasks.filter(x=>x.status!=='done').length;
 host.innerHTML=`<div class="pagehead"><div><span class="eyebrow">Minha empresa</span><h1>${esc(c.tradeName||c.name||'Meu negócio')}</h1><p>${esc(c.name||'')} ${c.document?'· CNPJ/CPF '+esc(c.document):''}</p></div><div class="actions"><button class="button secondary sm" id="resumo-cliente">Resumo do mês</button>${state.clientViews.length>1?`<select class="select" id="switch-company">${state.clientViews.map(v=>`<option value="${esc(viewKey(v))}" ${viewKey(v)===viewKey(row)?'selected':''}>${esc(v.info?.client?.name||'Empresa')}</option>`).join('')}</select>`:''}<label class="row"><span class="sub">Competência</span><input id="client-month" type="month" class="select" value="${esc(m)}"></label></div></div>
 <div class="notice mb20">Portal de consulta. Estes dados são publicados pelo seu atendimento contábil e podem ter atualização posterior aos documentos originais. Para confirmar pagamentos ou situações fiscais, consulte os comprovantes oficiais.</div>
 <div class="cards"><div class="card"><small>Notas emitidas · ${mon(m)}</small><strong>${brl(billing)}</strong><span>${invoices.filter(x=>x.status==='issued').length} nota(s) emitida(s)</span></div><div class="card"><small>Saldo das NFs a receber</small><strong>${brl(open)}</strong><span>Com base nos recebimentos registrados</span></div><div class="card"><small>Guias não pagas / em aberto</small><strong>${brl(taxOpen)}</strong><span>${taxes.filter(x=>x.status!=='paid').length} guia(s)</span></div><div class="card"><small>Atividades em aberto</small><strong>${taskOpen}</strong><span>Competência selecionada</span></div></div>
 <section id="agenda-vencimentos"></section>
 <div class="layout2"><div class="stack"><section class="panel"><div class="pad"><div class="panel-title">Minhas notas fiscais</div><div class="sub">Documentos registrados na competência</div></div><div class="table-wrap"><table class="table"><thead><tr><th>Nota / Data</th><th>Valor</th><th>Recebido</th><th>Situação</th></tr></thead><tbody>${invoices.length?invoices.map(x=>`<tr><td><strong>${esc(x.number||'Sem número')}</strong><small>${dbr(x.date)}</small></td><td>${brl(x.value)}</td><td>${brl(x.paid)}</td><td>${badgeStatus(x.status)}</td></tr>`).join(''):'<tr><td colspan="4">Nenhuma nota registrada nesta competência.</td></tr>'}</tbody></table></div></section>
 <section class="panel"><div class="pad"><div class="panel-title">Tributos e guias</div><div class="sub">Valores e vencimentos informados no sistema</div></div><div class="table-wrap"><table class="table"><thead><tr><th>Tributo</th><th>Vencimento</th><th>Valor</th><th>Condição</th></tr></thead><tbody>${taxes.length?taxes.map(x=>`<tr><td><strong>${esc(x.kind)}</strong></td><td>${dbr(x.dueDate)}</td><td>${brl(x.value)}</td><td>${badgeStatus(x.status)}</td></tr>`).join(''):'<tr><td colspan="4">Nenhum tributo registrado.</td></tr>'}</tbody></table></div></section></div>
 <div class="stack"><section class="panel pad"><div class="panel-title">Meu cadastro</div><div class="sub mb20">Informações cadastrais</div>${[['Razão social',c.name],['Regime tributário',c.regime],['Atividade',c.segment],['CNAE principal',c.activityCode],['Cidade / UF',[c.city,c.uf].filter(Boolean).join(' / ')],['E-mail de contato',c.email],['Situação cadastral',c.registryStatus]].map(([label,value])=>`<div class="row between" style="padding:11px 0;border-bottom:1px solid #eef3f3"><span class="sub">${esc(label)}</span><strong style="text-align:right;font-size:12px;max-width:65%">${esc(value||'—')}</strong></div>`).join('')}</section>
 <section class="panel"><div class="pad"><div class="panel-title">Pendências e atividades</div><div class="sub">Acompanhe o andamento do atendimento</div></div><div style="padding:0 22px 20px">${tasks.length?tasks.map(x=>`<div style="padding:13px 0;border-top:1px solid #edf3f3"><div class="row between"><strong style="font-size:12px">${esc(x.title)}</strong>${badgeStatus(x.status)}</div><div class="sub" style="margin-top:5px">Prazo: ${dbr(x.dueDate)} · ${esc(x.category||'Atendimento')}</div></div>`).join(''):'<p style="font-size:12px">Nenhuma pendência registrada.</p>'}</div></section></div></div><div class="footer-note">Última publicação: ${info.publishedAt?new Date(info.publishedAt).toLocaleString('pt-BR'):'não informada'} · Exibição somente para leitura</div>`;
 rotina.mountAgenda($('#agenda-vencimentos'),{taxes:info.taxes||[],tasks:info.tasks||[]},agendaView);
 $('#resumo-cliente').onclick=()=>rotina.showSummary({client:c,invoices,taxes,tasks},m,{
   demo:state.mode==='demo-client',publishedAt:row.published_at||info.publishedAt
 });
 const monthInput=$('#client-month');if(monthInput)monthInput.onchange=e=>{state.month=e.target.value||ym();renderClient()};const companyInput=$('#switch-company');if(companyInput)companyInput.onchange=e=>{agendaView=rotina.agendaView();state.selectedClient=e.target.value;renderClient()};
}
function accessFailure(e){
 root.innerHTML='<div class="login-main" style="min-height:100vh"><div class="login-card"><h2>Não foi possível carregar seu acesso</h2><div class="notice err mt20">'+esc(errMsg(e))+'</div><button id="retry" class="button mt20">Tentar novamente</button> <button id="signout" class="button secondary mt20">Sair</button></div></div>';
 $('#retry').onclick=routeUser;$('#signout').onclick=signout;
}
async function routeUser(){
 if(!sb || recovering)return;
 const generation=++routeGeneration, token=epoch;
 try{
  const {data:{user},error}=await sb.auth.getUser();
  if(generation!==routeGeneration||token!==epoch||recovering)return;
  if(error)throw error;
  if(!user){discard();authPage();return;}
  if(!user.email_confirmed_at)throw Error('Confirme seu e-mail antes de acessar o portal.');
  state.user=user;
  const a=await sb.from('clyriva_admins').select('user_id').eq('user_id',user.id).maybeSingle();
  if(generation!==routeGeneration||token!==epoch)return;
  if(a.error)throw a.error;
  if(a.data){await loadAdmin(user,token,generation);return;}
  const rows=await readAll('clyriva_client_views','admin_id,client_id,info,published_at',['admin_id','client_id']);
  if(generation!==routeGeneration||token!==epoch)return;
  state.clientViews=rows;state.mode='client';state.selectedClient=rows.length?viewKey(rows[0]):null;
  renderClient();startPortalRefresh();
 }catch(e){if(generation===routeGeneration && token===epoch){state.mode='error';state.frame=null;accessFailure(e);}}
}
async function refreshPortal(){
 if(state.mode!=='client'||!state.user||!sb||document.hidden||pollBusy)return;
 const token=epoch;pollBusy=true;
 try{
  const rows=await readAll('clyriva_client_views','admin_id,client_id,info,published_at',['admin_id','client_id']);
  if(token!==epoch||state.mode!=='client')return;
  if(JSON.stringify(rows)!==JSON.stringify(state.clientViews)||$('#portal-error')){
    state.clientViews=rows;renderClient();
  }
 }catch(e){
  if(token!==epoch||state.mode!=='client')return;
  state.clientViews=[];renderClient();
  const p=document.createElement('p');p.id='portal-error';p.className='notice warn';p.textContent='A verificação de acesso falhou. Os dados serão recarregados quando a conexão voltar.';
  $('#client-body').prepend(p);
 }finally{if(token===epoch)pollBusy=false;}
}
function startPortalRefresh(){clearInterval(portalPoll);portalPoll=setInterval(refreshPortal,60000);}
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshPortal();});
window.addEventListener('online',refreshPortal);
window.addEventListener('pageshow',e=>{
 if(e.persisted && sb){discard();authPage();sb.auth.getSession().then(({data})=>{if(data.session&&!recovering)routeUser();});}
});
window.addEventListener('beforeunload',e=>{if(state.saving){e.preventDefault();e.returnValue='';}});
async function signout(){
 if(state.saving)return;
 const wasDemo=state.mode.startsWith('demo-');
 discard();awaitingRecovery=false;recovering=false;authPage();
 if(sb&&!wasDemo){
  try{const {error}=await sb.auth.signOut({scope:'local'});if(error)throw error;}
  catch(e){accessFailure(Error('Falha ao encerrar a sessão no provedor. Tente sair novamente. '+errMsg(e)));$('#retry').onclick=signout;}
 }
}
function recoveryScreen(){
 discard();awaitingRecovery=false;recovering=true;authPage();resetPasswordPage();
}
function init(){
 wireLogin();
 if(!sb)return;
 sb.auth.onAuthStateChange((event,session)=>{
  if(event==='SIGNED_OUT'){discard();awaitingRecovery=false;recovering=false;authPage();return;}
  if(event==='PASSWORD_RECOVERY'){recoveryScreen();return;}
  if(recovering)return;
  if(awaitingRecovery){
    if(event==='INITIAL_SESSION')statusMessage('Para definir uma nova senha, abra um link de recuperação válido enviado ao seu e-mail.','warn');
    return;
  }
  if(!session)return;
  if(event==='INITIAL_SESSION'||event==='SIGNED_IN'||event==='TOKEN_REFRESHED'){
    if(state.user && state.user.id!==session.user.id){discard();authPage();}
    if(!state.authBusy && state.mode==='login')setTimeout(()=>{if(!recovering&&state.mode==='login')routeUser();},0);
  }
 });
}
init();
})();
